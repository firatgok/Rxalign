// Fotoğrafları IDS'e bırakmadan önce kırpar (kullanıcı kararı, 21 Ekim 2026). Küçültülmüş kareler
// arka plana (ids-crop) gider; model her kare için yuva ve kırpma kutusu verir; kırpma tarayıcıda
// tuvalde yapılır, klasördeki dosyalar değişmez. Çerçeve kuralları tools/crop-trial sayfasında
// kullanıcıyla denendi: yüz (profil/önden) = pay yok, dikey 2:3 (saçın biraz üstünden yakanın altına);
// ön ve yan ağız içi = modelin ölçümlerinden hesaplanan çerçeve (intraoralFrame); oklüzal = modelin kutusu.
// "other" ve düşük güvenli kareler olduğu gibi kalır; IDS'in otomatik sıralaması yine kendisi yapar.
(function () {
    'use strict';

    const SETTINGS = {
        maxSide: 1024,        // modele giden karenin uzun kenarı (piksel)
        margin: 0,            // ağız içi pay (%): çerçeveyi ekartör kolları belirlediği için pay yok (kullanıcı, 29 Ekim 2026)
        retractorKeep: 0.5,   // ekartör kolunun karede kalan payı (0.5 = kolun yarısı içeride)
        teethPad: 0.015,      // diş sınırı emniyeti (görüntü yüksekliğinin kesri)
        minTilt: 0.3,         // bunun altındaki oklüzal düzlem eğimi düzeltilmez (derece)
        maxTilt: 20,          // oklüzal düzlem düzeltmesi en çok bu kadar derece
        faceMargin: 0,        // yüz payı (%)
        faceRatio: 2 / 3,     // yüz en-boy (genişlik / yükseklik)
        maxImages: 30,        // tek istekte en çok bu kadar kare; fazlası olduğu gibi kalır
        minConfidence: 0.4,   // altında kırpılmaz
        quality: 0.92         // kırpılmış JPEG kalitesi
    };
    const FACE = /^(profile|frontal)_/;
    const INTRAORAL = /^(labial|buccal)_/;
    const NAMES = {
        profile_repose: 'profil', frontal_repose: 'önden', frontal_smiling: 'gülümseme',
        occlussal_upper: 'üst oklüzal', occlussal_lower: 'alt oklüzal', buccal_right: 'sağ bukkal',
        buccal_left: 'sol bukkal', labial_anterior: 'ağız içi önden', other: 'diğer'
    };

    function num(v) { const n = Number(v); return isFinite(n) ? n : 0; }

    function send(message) {
        return new Promise(function (resolve, reject) {
            if (!chrome.runtime || !chrome.runtime.id) {
                return reject(new Error('Eklenti güncellendi; bu sayfayı yenileyin (F5).'));
            }
            chrome.runtime.sendMessage(message, function (reply) {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!reply || !reply.ok) return reject(new Error(reply ? reply.error : 'yanıt yok'));
                resolve(reply);
            });
        });
    }

    // EXIF yönü uygulanmış kare: model kutuyu bu haliyle verir, kırpma da aynı haliyle yapılır.
    function bitmapOf(file) {
        return createImageBitmap(file, { imageOrientation: 'from-image' });
    }

    async function thumbnail(file) {
        const bitmap = await bitmapOf(file);
        try {
            const scale = Math.min(1, SETTINGS.maxSide / Math.max(bitmap.width, bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(bitmap.width * scale));
            canvas.height = Math.max(1, Math.round(bitmap.height * scale));
            canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
            return { w: bitmap.width, h: bitmap.height, data: canvas.toDataURL('image/jpeg', 0.85).split(',')[1] };
        } finally {
            bitmap.close();
        }
    }

    // Pay ve en-boy uygulanmış son kutu (kesirler). Görüntü dışına taşarsa kaydırılır, sığmazsa kırpılır.
    function finalBox(box, marginPct, ratio, w, h) {
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        [x0, y0, x1, y1] = [x0, y0, x1, y1].map(function (v) { return Math.min(1, Math.max(0, Number(v) || 0)); });
        if (x1 <= x0 || y1 <= y0) return null;
        const m = marginPct / 100;
        const bw = x1 - x0, bh = y1 - y0;
        x0 -= bw * m; x1 += bw * m; y0 -= bh * m; y1 += bh * m;
        if (ratio) {
            const pw = (x1 - x0) * w, ph = (y1 - y0) * h;
            if (pw / ph < ratio) {
                const nw = ph * ratio, cx = (x0 + x1) / 2 * w;
                x0 = (cx - nw / 2) / w; x1 = (cx + nw / 2) / w;
            } else {
                const nh = pw / ratio, cy = (y0 + y1) / 2 * h;
                y0 = (cy - nh / 2) / h; y1 = (cy + nh / 2) / h;
            }
        }
        if (x0 < 0) { x1 -= x0; x0 = 0; }
        if (y0 < 0) { y1 -= y0; y0 = 0; }
        if (x1 > 1) { x0 -= x1 - 1; x1 = 1; }
        if (y1 > 1) { y0 -= y1 - 1; y1 = 1; }
        return [Math.max(0, x0), Math.max(0, y0), Math.min(1, x1), Math.min(1, y1)];
    }

    // Ön ve yan ağız içi kare: çerçeve modelin kutusundan değil ölçümlerinden hesaplanır (kullanıcı ince
    // ayarı, 29 Ekim 2026: model "kolun yarısı içeride" kutusunu tutturamıyordu; ölçüm + hesap daha güvenilir).
    //   plane_x0..plane_y1 : oklüzal düzlemin iki ucu → eğim (sağa doğru aşağı = pozitif); görüntü kutu
    //                        merkezi (pivot) etrafında -eğim kadar döndürülür, düzlem yere paralel olur.
    //   arms[]             : ekartör kolu {x, top, bottom}; üst/alt kol düzleme göre ayrılır (kare ters
    //                        olsa da çalışır); kesme noktası kolun dişe bakan kenarından retractorKeep
    //                        oranında dışarıda; döndürülmüş karede y alınır, üst/alt kenar ortalamadır.
    //   teeth_top/bottom   : diş tacı sınırı → emniyet, hiçbir diş kesilmez.
    // Düzlem 45°'den eğikse (kare yan duruyor) ölçümlere güvenilmez, modelin kutusu olduğu gibi kalır.
    // w, h: görüntü boyutu (piksel). Dönüş: box döndürülmüş karede kesirler; tilt derece; pivot kesir.
    function intraoralFrame(item, w, h) {
        const box = [num(item.x0), num(item.y0), num(item.x1), num(item.y1)];
        const pivot = [(box[0] + box[2]) / 2, (box[1] + box[3]) / 2];
        let p0 = [num(item.plane_x0), num(item.plane_y0)], p1 = [num(item.plane_x1), num(item.plane_y1)];
        if (p0[0] > p1[0]) { const t = p0; p0 = p1; p1 = t; }
        const dx = (p1[0] - p0[0]) * w, dy = (p1[1] - p0[1]) * h;
        const hasPlane = dx > 0.05 * w;
        const angle = hasPlane ? Math.atan2(dy, dx) * 180 / Math.PI : 0;
        const sideways = Math.abs(angle) > 45;
        let tilt = sideways ? 0 : angle;
        if (Math.abs(tilt) < SETTINGS.minTilt || Math.abs(tilt) > SETTINGS.maxTilt) tilt = 0;
        const rad = -tilt * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
        const px = pivot[0] * w, py = pivot[1] * h;
        // Noktanın döndürülmüş karedeki y'si (kesir).
        const rotY = function (x, y) { const X = x * w - px, Y = y * h - py; return (X * sin + Y * cos + py) / h; };
        const planeY = function (x) {
            return hasPlane ? p0[1] + (x - p0[0]) * (p1[1] - p0[1]) / (p1[0] - p0[0]) : pivot[1];
        };
        let y0 = box[1], y1 = box[3];
        const arms = [];
        let teeth = null;
        if (!sideways) {
            (Array.isArray(item.arms) ? item.arms : []).forEach(function (arm) {
                const x = num(arm.x), top = num(arm.top), bottom = num(arm.bottom), keep = SETTINGS.retractorKeep;
                if (!(bottom > top) || bottom - top > 0.25) return;
                const upper = (top + bottom) / 2 < planeY(x);
                const cut = upper ? bottom - keep * (bottom - top) : top + keep * (bottom - top);
                arms.push({ x: x, top: top, bottom: bottom, cut: cut, upper: upper, y: rotY(x, cut) });
            });
            const mean = function (a) { return a.reduce(function (s, v) { return s + v; }, 0) / a.length; };
            const ups = arms.filter(function (a) { return a.upper; }).map(function (a) { return a.y; });
            const lows = arms.filter(function (a) { return !a.upper; }).map(function (a) { return a.y; });
            if (ups.length) y0 = mean(ups);
            if (lows.length) y1 = mean(lows);
            const tt = num(item.teeth_top), tb = num(item.teeth_bottom);
            if (tb > tt) {
                teeth = [tt, tb];
                y0 = Math.min(y0, rotY(pivot[0], tt) - SETTINGS.teethPad);
                y1 = Math.max(y1, rotY(pivot[0], tb) + SETTINGS.teethPad);
            }
        }
        if (!(y1 - y0 > 0.1)) { y0 = box[1]; y1 = box[3]; }
        return {
            box: [box[0], y0, box[2], y1], tilt: tilt, angle: angle, pivot: pivot,
            plane: hasPlane ? [p0[0], p0[1], p1[0], p1[1]] : null, teeth: teeth, arms: arms,
            upper: arms.filter(function (a) { return a.upper; }).length,
            lower: arms.filter(function (a) { return !a.upper; }).length
        };
    }

    function toBlob(canvas) {
        return new Promise(function (resolve) { canvas.toBlob(resolve, 'image/jpeg', SETTINGS.quality); });
    }

    // 16×16 gri imza: IDS yuvasındaki önizlemenin hangi kırpılmış dosya olduğunu bulmak için.
    const SIG = 16;
    function signatureOf(source, w, h) {
        const canvas = document.createElement('canvas');
        canvas.width = SIG;
        canvas.height = SIG;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(source, 0, 0, w, h, 0, 0, SIG, SIG);
        const px = ctx.getImageData(0, 0, SIG, SIG).data;
        const out = new Array(SIG * SIG);
        for (let i = 0; i < out.length; i++) out[i] = px[i * 4] * 0.299 + px[i * 4 + 1] * 0.587 + px[i * 4 + 2] * 0.114;
        return out;
    }

    function distance(a, b) {
        let sum = 0;
        for (let i = 0; i < a.length; i++) sum += Math.abs(a[i] - b[i]);
        return sum / a.length;
    }

    // Önizleme (IDS'in küçülttüğü yüklenmiş kare) hangi kırpılmış dosyaya ait? Belirsizse null.
    async function matchOriginal(blob, items) {
        if (!items || !items.length) return null;
        const bitmap = await createImageBitmap(blob);
        try {
            const sig = signatureOf(bitmap, bitmap.width, bitmap.height);
            const ranked = items.filter(function (it) { return it.sig; })
                .map(function (it) { return { item: it, d: distance(sig, it.sig) }; })
                .sort(function (a, b) { return a.d - b.d; });
            if (!ranked.length || ranked[0].d > 20) return null;
            if (ranked[1] && ranked[1].d < ranked[0].d + 8) return null;
            return ranked[0].item;
        } finally {
            bitmap.close();
        }
    }

    // box: kesirler (eğim varsa döndürülmüş karede); tilt: oklüzal düzlemin eğimi (derece, sağa doğru
    // aşağı = pozitif); pivot: döndürme merkezi (kesir). Görüntü pivot etrafında -tilt döndürülüp kutu
    // o karede kesilir (oklüzal düzlem yere paralel olur).
    async function cropOne(file, box, tilt, pivot) {
        const bitmap = await bitmapOf(file);
        try {
            const sx = Math.round(box[0] * bitmap.width), sy = Math.round(box[1] * bitmap.height);
            const sw = Math.max(1, Math.round((box[2] - box[0]) * bitmap.width));
            const sh = Math.max(1, Math.round((box[3] - box[1]) * bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = sw;
            canvas.height = sh;
            const ctx = canvas.getContext('2d');
            if (tilt) {
                const px = (pivot ? pivot[0] : (box[0] + box[2]) / 2) * bitmap.width;
                const py = (pivot ? pivot[1] : (box[1] + box[3]) / 2) * bitmap.height;
                ctx.fillStyle = '#000';
                ctx.fillRect(0, 0, sw, sh);
                ctx.translate(px - sx, py - sy);
                ctx.rotate(-tilt * Math.PI / 180);
                ctx.translate(-px, -py);
                ctx.drawImage(bitmap, 0, 0);
                ctx.setTransform(1, 0, 0, 1, 0, 0);
            } else {
                ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
            }
            const sig = signatureOf(canvas, sw, sh);
            const blob = await toBlob(canvas);
            if (!blob) throw new Error('kırpılmış görüntü üretilemedi');
            const name = file.name.replace(/\.[^.]+$/, '') + '.jpg';
            return { file: new File([blob], name, { type: 'image/jpeg', lastModified: file.lastModified }), width: sw, height: sh, sig: sig };
        } finally {
            bitmap.close();
        }
    }

    // files: File dizisi; progress(metin) ilerlemeyi bildirir.
    // Dönüş: { files (aynı sırada, kırpılanlar yeni File), cropped, total, notes[] }.
    async function cropFiles(files, progress) {
        const say = progress || function () {};
        const batch = files.slice(0, SETTINGS.maxImages);
        const infos = [];
        for (let i = 0; i < batch.length; i++) {
            say('Fotoğraflar kırpma için hazırlanıyor… (' + (i + 1) + '/' + batch.length + ')');
            infos.push(await thumbnail(batch[i]));
        }
        say(batch.length + ' fotoğraf için kırpma kutuları isteniyor…');
        const reply = await send({
            type: 'ids-crop',
            images: infos.map(function (info, i) { return { index: i + 1, data: info.data }; })
        });
        const items = reply.items || [];
        const out = files.slice();
        const notes = [];
        // Kırpılan her kare için: modelin yuvası, kırpılmış boyut, imza ve kırpılmamış küçük kare
        // (yön okuması kırpılmış yerine bu kareden yapılır: burun, çene, ekartör gibi ipuçları kalsın).
        const cropItems = [];
        let cropped = 0;
        for (let i = 0; i < batch.length; i++) {
            const file = batch[i];
            const item = items.find(function (it) { return Number(it.index) === i + 1; });
            if (!item || item.slot === 'other' || !(Number(item.confidence) >= SETTINGS.minConfidence)) {
                if (item && item.note) notes.push(file.name + ': ' + item.note);
                continue;
            }
            const face = FACE.test(item.slot);
            const frame = INTRAORAL.test(item.slot) ? intraoralFrame(item, infos[i].w, infos[i].h) : null;
            const box = finalBox(frame ? frame.box : [item.x0, item.y0, item.x1, item.y1],
                face ? SETTINGS.faceMargin : SETTINGS.margin, face ? SETTINGS.faceRatio : 0, infos[i].w, infos[i].h);
            if (!box) continue;
            say('Kırpılıyor: ' + file.name + ' (' + (NAMES[item.slot] || item.slot) + ')…');
            const tilt = frame ? frame.tilt : 0;
            try {
                const result = await cropOne(file, box, tilt, frame ? frame.pivot : null);
                if (tilt) notes.push(file.name + ': oklüzal düzlem ' + Math.abs(tilt).toFixed(1) + '° düzeltildi');
                if (frame && !frame.upper && !frame.lower) notes.push(file.name + ': ekartör kolu ölçülemedi, modelin kutusu kullanıldı');
                out[i] = result.file;
                cropItems.push({ name: file.name, slot: item.slot, width: result.width, height: result.height,
                    sig: result.sig, thumb: infos[i].data });
                cropped++;
                if (item.note) notes.push(file.name + ': ' + item.note);
            } catch (error) {
                notes.push(file.name + ': kırpılamadı (' + error.message + ')');
            }
        }
        return { files: out, cropped: cropped, total: batch.length, notes: notes, items: cropItems };
    }

    window.idsfyCrop = { cropFiles: cropFiles, finalBox: finalBox, intraoralFrame: intraoralFrame, matchOriginal: matchOriginal, SETTINGS: SETTINGS };
})();
