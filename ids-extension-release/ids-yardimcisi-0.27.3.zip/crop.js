// Fotoğrafları IDS'e bırakmadan önce kırpar (kullanıcı kararı, 21 Ekim 2026). Küçültülmüş kareler
// arka plana (ids-crop) gider; model her kare için yuva ve kırpma kutusu verir; kırpma tarayıcıda
// tuvalde yapılır, klasördeki dosyalar değişmez. Çerçeve kuralları tools/crop-trial sayfasında
// kullanıcıyla denendi: yüz (profil/önden) = pay yok, dikey 2:3 (saçın biraz üstünden yakanın altına);
// ön ve yan ağız içi = modelin ölçümlerinden hesaplanan çerçeve (intraoralFrame); oklüzal = modelin kutusu.
// "other" ve düşük güvenli kareler olduğu gibi kalır; IDS'in otomatik sıralaması yine kendisi yapar.
(function () {
    'use strict';

    const SETTINGS = {
        maxSide: 1024,        // modele giden karenin uzun kenarı (piksel)
        margin: 0,            // ağız içi pay (%): çerçeveyi ekartör kolları belirlediği için pay yok (kullanıcı, 29 Ekim 2026)
        retractorKeep: 0.3,   // ekartör kolunun karede kalan payı (0.3 = kolun %30'u içeride; yarıdan indirildi, kullanıcı 29 Ekim 2026: dudak biraz daha kesilsin)
        balance: 1.4,         // oklüzal düzlemin üstü/altı bu orandan dengesizse uzun tarafta dudak kıvrımı esas alınır
        teethPad: 0.015,      // diş sınırı emniyeti, dikey (görüntü yüksekliğinin kesri)
        teethPadX: 0.01,      // diş sınırı emniyeti, yatay (görüntü genişliğinin kesri)
        minTilt: 0.3,         // bunun altındaki oklüzal düzlem eğimi düzeltilmez (derece)
        maxTilt: 20,          // oklüzal düzlem düzeltmesi en çok bu kadar derece
        faceMargin: 0,        // yüz payı (%)
        faceRatio: 2 / 3,     // yüz en-boy (genişlik / yükseklik)
        maxImages: 30,        // bir klasörden en çok bu kadar kare kırpılır; fazlası olduğu gibi kalır
        groupSize: 6,         // model her istekte en çok bu kadar kareye bakar; gruplar aynı anda sorulur
        prepareParallel: 3,   // aynı anda çözülen tam boyutlu kare sayısı (küçük kare hazırlığı)
        cropParallel: 2,      // aynı anda kırpılan tam boyutlu kare sayısı
        minConfidence: 0.4,   // altında kırpılmaz
        quality: 0.92         // kırpılmış JPEG kalitesi
    };
    const FACE = /^(profile|frontal)_/;
    const INTRAORAL = /^(labial|buccal)_/;
    const NAMES = {
        profile_repose: 'profil', frontal_repose: 'önden', frontal_smiling: 'gülümseme',
        occlussal_upper: 'üst oklüzal', occlussal_lower: 'alt oklüzal', buccal_right: 'sağ bukkal',
        buccal_left: 'sol bukkal', labial_anterior: 'ağız içi önden', other: 'diğer'
    };

    function num(v) { const n = Number(v); return isFinite(n) ? n : 0; }

    function send(message) {
        return new Promise(function (resolve, reject) {
            if (!chrome.runtime || !chrome.runtime.id) {
                return reject(new Error('Eklenti güncellendi; bu sayfayı yenileyin (F5).'));
            }
            chrome.runtime.sendMessage(message, function (reply) {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!reply || !reply.ok) return reject(new Error(reply ? reply.error : 'yanıt yok'));
                resolve(reply);
            });
        });
    }

    // EXIF yönü uygulanmış kare: model kutuyu bu haliyle verir, kırpma da aynı haliyle yapılır.
    function bitmapOf(file) {
        return createImageBitmap(file, { imageOrientation: 'from-image' });
    }

    // Aynı görünümün tekrar çekimlerini karşılaştırmak için: 256 piksellik gri kareden ortalama parlaklık (0-255)
    // ve netlik (Laplace varyansı). Kıyas yalnızca aynı görünümün kareleri arasında anlamlıdır.
    function qualityOf(source) {
        const w = 256;
        const h = Math.max(8, Math.round(w * source.height / source.width));
        const c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        const ctx = c.getContext('2d');
        ctx.drawImage(source, 0, 0, w, h);
        const px = ctx.getImageData(0, 0, w, h).data;
        const gray = new Float32Array(w * h);
        let sum = 0;
        for (let i = 0; i < gray.length; i++) {
            gray[i] = px[i * 4] * 0.299 + px[i * 4 + 1] * 0.587 + px[i * 4 + 2] * 0.114;
            sum += gray[i];
        }
        let lap = 0, lap2 = 0, n = 0;
        for (let y = 1; y < h - 1; y++) {
            for (let x = 1; x < w - 1; x++) {
                const i = y * w + x;
                const v = 4 * gray[i] - gray[i - 1] - gray[i + 1] - gray[i - w] - gray[i + w];
                lap += v;
                lap2 += v * v;
                n++;
            }
        }
        const mean = lap / n;
        return { bright: sum / gray.length, sharp: lap2 / n - mean * mean };
    }

    // Aday sıralaması: pozlaması dengeli (ne karanlık ne patlamış) ve net olan önde.
    function qualityScore(it) {
        const exposure = Math.max(0.05, 1 - Math.abs((Number(it.bright) || 0) - 125) / 125);
        return (Number(it.sharp) || 0) * exposure;
    }

    async function thumbnail(file) {
        const bitmap = await bitmapOf(file);
        try {
            const scale = Math.min(1, SETTINGS.maxSide / Math.max(bitmap.width, bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(bitmap.width * scale));
            canvas.height = Math.max(1, Math.round(bitmap.height * scale));
            canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
            const q = qualityOf(canvas);
            return { w: bitmap.width, h: bitmap.height, data: canvas.toDataURL('image/jpeg', 0.85).split(',')[1],
                bright: q.bright, sharp: q.sharp };
        } finally {
            bitmap.close();
        }
    }

    // Pay ve en-boy uygulanmış son kutu (kesirler). Görüntü dışına taşarsa kaydırılır, sığmazsa kırpılır.
    function finalBox(box, marginPct, ratio, w, h) {
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        [x0, y0, x1, y1] = [x0, y0, x1, y1].map(function (v) { return Math.min(1, Math.max(0, Number(v) || 0)); });
        if (x1 <= x0 || y1 <= y0) return null;
        const m = marginPct / 100;
        const bw = x1 - x0, bh = y1 - y0;
        x0 -= bw * m; x1 += bw * m; y0 -= bh * m; y1 += bh * m;
        if (ratio) {
            const pw = (x1 - x0) * w, ph = (y1 - y0) * h;
            if (pw / ph < ratio) {
                const nw = ph * ratio, cx = (x0 + x1) / 2 * w;
                x0 = (cx - nw / 2) / w; x1 = (cx + nw / 2) / w;
            } else {
                const nh = pw / ratio, cy = (y0 + y1) / 2 * h;
                y0 = (cy - nh / 2) / h; y1 = (cy + nh / 2) / h;
            }
        }
        if (x0 < 0) { x1 -= x0; x0 = 0; }
        if (y0 < 0) { y1 -= y0; y0 = 0; }
        if (x1 > 1) { x0 -= x1 - 1; x1 = 1; }
        if (y1 > 1) { y0 -= y1 - 1; y1 = 1; }
        return [Math.max(0, x0), Math.max(0, y0), Math.min(1, x1), Math.min(1, y1)];
    }

    // Ön ve yan ağız içi kare: çerçeve modelin kutusundan değil ölçümlerinden hesaplanır (kullanıcı ince
    // ayarı, 29 Ekim 2026: model "kolun yarısı içeride" kutusunu tutturamıyordu; ölçüm + hesap daha güvenilir).
    //   plane_x0..plane_y1 : oklüzal düzlemin iki ucu → eğim (sağa doğru aşağı = pozitif); görüntü kutu
    //                        merkezi (pivot) etrafında -eğim kadar döndürülür, düzlem yere paralel olur.
    //   arms[]             : ekartör kolu {x, top, bottom}; üst/alt kol düzleme göre ayrılır (kare ters
    //                        olsa da çalışır); kesme noktası kolun dişe bakan kenarından retractorKeep
    //                        oranında dışarıda; döndürülmüş karede y alınır, üst/alt kenar ortalamadır.
    //   lip_upper_y/lower  : dudak-dişeti kıvrımı; düzlemin üstü/altı çok dengesizse (balance) uzun tarafta
    //                        ekartör yerine bu kıvrım kenar olur (kullanıcı, 29 Ekim 2026).
    //   c_left/right_x     : C ekartörün iç bükey ucu → o yanın kenarı (C'nin sırtı ve yanak dışarıda).
    //   far_left/right_x   : karşı ekartörün dişe bakan kenarı → o yan dişe yaklaşır, karşı ekartör dışarıda.
    //   teeth_*            : diş tacı sınırı → emniyet, hiçbir diş kesilmez.
    // Döndürme köşeleri görüntü dışına taşırırsa o yan içeri çekilir (siyah köşe kalmasın).
    // Düzlem 45°'den eğikse (kare yan duruyor) ölçümlere güvenilmez, modelin kutusu olduğu gibi kalır.
    // w, h: görüntü boyutu (piksel). Dönüş: box döndürülmüş karede kesirler; tilt derece; pivot kesir.
    function intraoralFrame(item, w, h) {
        const box = [num(item.x0), num(item.y0), num(item.x1), num(item.y1)];
        const pivot = [(box[0] + box[2]) / 2, (box[1] + box[3]) / 2];
        let p0 = [num(item.plane_x0), num(item.plane_y0)], p1 = [num(item.plane_x1), num(item.plane_y1)];
        if (p0[0] > p1[0]) { const t = p0; p0 = p1; p1 = t; }
        const dx = (p1[0] - p0[0]) * w, dy = (p1[1] - p0[1]) * h;
        const hasPlane = Math.hypot(dx, dy) > 0.05 * Math.min(w, h);
        const angle = hasPlane ? Math.atan2(dy, dx) * 180 / Math.PI : 0;
        const sideways = Math.abs(angle) > 45;
        let tilt = sideways ? 0 : angle;
        if (Math.abs(tilt) < SETTINGS.minTilt || Math.abs(tilt) > SETTINGS.maxTilt) tilt = 0;
        const rad = -tilt * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
        const px = pivot[0] * w, py = pivot[1] * h;
        // Noktanın döndürülmüş karedeki x'i / y'si (kesir) ve döndürülmüş karedeki noktanın orijinalde içeride olup olmadığı.
        const rotX = function (x, y) { const X = x * w - px, Y = y * h - py; return (X * cos - Y * sin + px) / w; };
        const rotY = function (x, y) { const X = x * w - px, Y = y * h - py; return (X * sin + Y * cos + py) / h; };
        const inside = function (x, y) {
            const X = x * w - px, Y = y * h - py;
            const ox = (px + X * cos + Y * sin) / w, oy = (py - X * sin + Y * cos) / h;
            return ox >= 0 && ox <= 1 && oy >= 0 && oy <= 1;
        };
        const planeY = function (x) {
            return hasPlane ? p0[1] + (x - p0[0]) * (p1[1] - p0[1]) / (p1[0] - p0[0]) : pivot[1];
        };
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        const arms = [];
        const used = { lip: '', sides: [] };
        let teeth = null, lips = null, sides = null;
        if (!sideways) {
            // Üst/alt kenar: ekartör kollarının kesme noktaları (döndürülmüş karede, ortalama).
            (Array.isArray(item.arms) ? item.arms : []).forEach(function (arm) {
                const x = num(arm.x), top = num(arm.top), bottom = num(arm.bottom), keep = SETTINGS.retractorKeep;
                if (!(bottom > top) || bottom - top > 0.25) return;
                const upper = (top + bottom) / 2 < planeY(x);
                const cut = upper ? bottom - keep * (bottom - top) : top + keep * (bottom - top);
                arms.push({ x: x, top: top, bottom: bottom, cut: cut, upper: upper, y: rotY(x, cut) });
            });
            const mean = function (a) { return a.reduce(function (s, v) { return s + v; }, 0) / a.length; };
            const ups = arms.filter(function (a) { return a.upper; }).map(function (a) { return a.y; });
            const lows = arms.filter(function (a) { return !a.upper; }).map(function (a) { return a.y; });
            if (ups.length) y0 = mean(ups);
            if (lows.length) y1 = mean(lows);
            // Denge: düzlemin üstü ile altı çok dengesizse uzun tarafta ekartör yerine dudak-dişeti kıvrımı.
            const lu = num(item.lip_upper_y), ll = num(item.lip_lower_y);
            lips = [lu, ll];
            if (hasPlane) {
                const cx = (p0[0] + p1[0]) / 2;
                const pc = rotY(cx, planeY(cx));
                const up = pc - y0, down = y1 - pc;
                if (up > 0 && down > 0) {
                    if (up > down * SETTINGS.balance && lu > 0) {
                        const yl = rotY(cx, lu);
                        if (yl > y0 && yl < pc) { y0 = yl; used.lip = 'üst'; }
                    } else if (down > up * SETTINGS.balance && ll > 0) {
                        const yl = rotY(cx, ll);
                        if (yl < y1 && yl > pc) { y1 = yl; used.lip = 'alt'; }
                    }
                }
            }
            // Yanlar: C'nin iç bükey ucu (C'nin sırtı dışarıda), karşı ekartörün dişe bakan kenarı (karşı ekartör dışarıda).
            sides = { cl: num(item.c_left_x), fl: num(item.far_left_x), cr: num(item.c_right_x), fr: num(item.far_right_x) };
            [[sides.cl, 'sol C'], [sides.fl, 'sol karşı ekartör']].forEach(function (c) {
                if (c[0] > 0 && c[0] < 1) { const r = rotX(c[0], pivot[1]); if (r > x0) { x0 = r; used.sides.push(c[1]); } }
            });
            [[sides.cr, 'sağ C'], [sides.fr, 'sağ karşı ekartör']].forEach(function (c) {
                if (c[0] > 0 && c[0] < 1) { const r = rotX(c[0], pivot[1]); if (r < x1) { x1 = r; used.sides.push(c[1]); } }
            });
            // Diş emniyeti: hiçbir diş kesilmez.
            const tt = num(item.teeth_top), tb = num(item.teeth_bottom), tl = num(item.teeth_left), tr = num(item.teeth_right);
            if (tb > tt) {
                teeth = [tt, tb];
                y0 = Math.min(y0, rotY(pivot[0], tt) - SETTINGS.teethPad);
                y1 = Math.max(y1, rotY(pivot[0], tb) + SETTINGS.teethPad);
            }
            if (tr > tl) {
                x0 = Math.min(x0, rotX(tl, pivot[1]) - SETTINGS.teethPadX);
                x1 = Math.max(x1, rotX(tr, pivot[1]) + SETTINGS.teethPadX);
            }
            // Döndürme köşeleri görüntü dışına taşırırsa o yan içeri çekilir (siyah köşe kalmasın; en çok %25).
            if (tilt) {
                const limit0 = x0 + (x1 - x0) * 0.25, limit1 = x1 - (x1 - x0) * 0.25;
                while (x0 < limit0 && !(inside(x0, y0) && inside(x0, y1))) x0 += 0.003;
                while (x1 > limit1 && !(inside(x1, y0) && inside(x1, y1))) x1 -= 0.003;
            }
        }
        if (!(y1 - y0 > 0.1) || !(x1 - x0 > 0.2)) { x0 = box[0]; y0 = box[1]; x1 = box[2]; y1 = box[3]; }
        return {
            box: [x0, y0, x1, y1], tilt: tilt, angle: angle, pivot: pivot,
            plane: hasPlane ? [p0[0], p0[1], p1[0], p1[1]] : null, teeth: teeth, lips: lips, sides: sides, arms: arms, used: used,
            upper: arms.filter(function (a) { return a.upper; }).length,
            lower: arms.filter(function (a) { return !a.upper; }).length
        };
    }

    function toBlob(canvas) {
        return new Promise(function (resolve) { canvas.toBlob(resolve, 'image/jpeg', SETTINGS.quality); });
    }

    // 16×16 gri imza: IDS yuvasındaki önizlemenin hangi kırpılmış dosya olduğunu bulmak için.
    const SIG = 16;
    function signatureOf(source, w, h) {
        const canvas = document.createElement('canvas');
        canvas.width = SIG;
        canvas.height = SIG;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(source, 0, 0, w, h, 0, 0, SIG, SIG);
        const px = ctx.getImageData(0, 0, SIG, SIG).data;
        const out = new Array(SIG * SIG);
        for (let i = 0; i < out.length; i++) out[i] = px[i * 4] * 0.299 + px[i * 4 + 1] * 0.587 + px[i * 4 + 2] * 0.114;
        return out;
    }

    function distance(a, b) {
        let sum = 0;
        for (let i = 0; i < a.length; i++) sum += Math.abs(a[i] - b[i]);
        return sum / a.length;
    }

    // Önizleme (IDS'in küçülttüğü yüklenmiş kare) hangi kırpılmış dosyaya ait? En iyi eşleşmeye yakın (+8) olanların
    // hepsi döner: benzer çekimler (ikizler) imzayla ayırt edilemez; hepsi aynı hedef yuvadaysa hangisi olduğu önemsizdir.
    // Hiçbiri yeterince yakın değilse boş dizi.
    async function matchGroup(blob, items) {
        if (!items || !items.length) return [];
        const bitmap = await createImageBitmap(blob);
        try {
            const sig = signatureOf(bitmap, bitmap.width, bitmap.height);
            const ranked = items.filter(function (it) { return it.sig; })
                .map(function (it) { return { item: it, d: distance(sig, it.sig) }; })
                .sort(function (a, b) { return a.d - b.d; });
            if (!ranked.length || ranked[0].d > 20) return [];
            return ranked.filter(function (r) { return r.d < ranked[0].d + 8; }).map(function (r) { return r.item; });
        } finally {
            bitmap.close();
        }
    }

    // Belirsizse (benzer çekimler) null.
    async function matchOriginal(blob, items) {
        const group = await matchGroup(blob, items);
        return group.length === 1 ? group[0] : null;
    }

    // Ham karede üst çenenin ve ön dişlerin yönünden ağız içi yan karenin yanı: üst çene yukarı gelecek şekilde
    // döndürülünce ön dişler sağdaysa sağ bukkal, soldaysa sol bukkal (kliniğin kuralı; fotoğraflar aynasız çekilir).
    // Belirsizse null.
    const SIDE_DEG = { top: 0, right: 90, bottom: 180, left: 270 };
    function buccalSide(upper, incisors) {
        const u = SIDE_DEG[upper];
        const n = SIDE_DEG[incisors];
        if (u === undefined || n === undefined) return null;
        const after = (((n - u) % 360) + 360) % 360;
        return after === 90 ? 'buccal_right' : after === 270 ? 'buccal_left' : null;
    }

    // box: kesirler (eğim varsa döndürülmüş karede); tilt: oklüzal düzlemin eğimi (derece, sağa doğru
    // aşağı = pozitif); pivot: döndürme merkezi (kesir). Görüntü pivot etrafında -tilt döndürülüp kutu
    // o karede kesilir (oklüzal düzlem yere paralel olur).
    async function cropOne(file, box, tilt, pivot) {
        const bitmap = await bitmapOf(file);
        try {
            const sx = Math.round(box[0] * bitmap.width), sy = Math.round(box[1] * bitmap.height);
            const sw = Math.max(1, Math.round((box[2] - box[0]) * bitmap.width));
            const sh = Math.max(1, Math.round((box[3] - box[1]) * bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = sw;
            canvas.height = sh;
            const ctx = canvas.getContext('2d');
            if (tilt) {
                const px = (pivot ? pivot[0] : (box[0] + box[2]) / 2) * bitmap.width;
                const py = (pivot ? pivot[1] : (box[1] + box[3]) / 2) * bitmap.height;
                ctx.fillStyle = '#000';
                ctx.fillRect(0, 0, sw, sh);
                ctx.translate(px - sx, py - sy);
                ctx.rotate(-tilt * Math.PI / 180);
                ctx.translate(-px, -py);
                ctx.drawImage(bitmap, 0, 0);
                ctx.setTransform(1, 0, 0, 1, 0, 0);
            } else {
                ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
            }
            const sig = signatureOf(canvas, sw, sh);
            const blob = await toBlob(canvas);
            if (!blob) throw new Error('kırpılmış görüntü üretilemedi');
            const name = file.name.replace(/\.[^.]+$/, '') + '.jpg';
            return { file: new File([blob], name, { type: 'image/jpeg', lastModified: file.lastModified }), width: sw, height: sh, sig: sig };
        } finally {
            bitmap.close();
        }
    }

    // En çok `limit` iş aynı anda çalışır (tam boyutlu kareler bellekte büyüktür).
    function limiter(limit) {
        let active = 0;
        const queue = [];
        const next = function () {
            if (active >= limit || !queue.length) return;
            active++;
            const job = queue.shift();
            job.fn().then(job.resolve, job.reject).then(function () { active--; next(); });
        };
        return function (fn) {
            return new Promise(function (resolve, reject) { queue.push({ fn: fn, resolve: resolve, reject: reject }); next(); });
        };
    }

    // files: File dizisi; progress(metin) ilerlemeyi bildirir.
    // Dönüş: { files (aynı sırada, kırpılanlar yeni File), cropped, total, notes[], items[], timing }.
    // Süre: küçük kareler paralel hazırlanır; fotoğraflar groupSize'lık gruplara bölünüp model aynı anda
    // sorulur (her kare tek başına değerlendirilir, süre en uzun grubun süresi kadar olur) ve bir grup
    // yanıtlayınca o grubun kareleri hemen kırpılır.
    async function cropFiles(files, progress) {
        const say = progress || function () {};
        const started = Date.now();
        const secs = function (from) { return Math.round((Date.now() - from) / 1000); };
        const batch = files.slice(0, SETTINGS.maxImages);

        let prepared = 0;
        const prepare = limiter(SETTINGS.prepareParallel);
        const infos = await Promise.all(batch.map(function (file) {
            return prepare(async function () {
                const info = await thumbnail(file);
                prepared++;
                say('Fotoğraflar hazırlanıyor… (' + prepared + '/' + batch.length + ')');
                return info;
            });
        }));
        const preparedAt = Date.now();

        const groupCount = Math.max(1, Math.ceil(batch.length / SETTINGS.groupSize));
        const per = Math.ceil(batch.length / groupCount);
        const groups = [];
        for (let g = 0; g < groupCount; g++) {
            const idx = [];
            for (let i = g * per; i < Math.min(batch.length, (g + 1) * per); i++) idx.push(i);
            if (idx.length) groups.push(idx);
        }

        const out = files.slice();
        const noteBy = batch.map(function () { return []; });
        // Kırpılan her kare için: modelin yuvası, kırpılmış dosya, imza ve kırpılmamış küçük kare (yön okuması
        // kırpılmış yerine bu kareden yapılır: burun, çene, ekartör gibi ipuçları kalsın).
        const cropBy = new Array(batch.length);
        const errors = [];
        let answered = 0;
        let finished = 0;
        const cropLimit = limiter(SETTINGS.cropParallel);

        async function cropIndex(i, items) {
            const file = batch[i];
            const item = items.find(function (it) { return Number(it.index) === i + 1; });
            if (!item || item.slot === 'other' || !(Number(item.confidence) >= SETTINGS.minConfidence)) {
                if (item && item.note) noteBy[i].push(file.name + ': ' + item.note);
                return;
            }
            const face = FACE.test(item.slot);
            const frame = INTRAORAL.test(item.slot) ? intraoralFrame(item, infos[i].w, infos[i].h) : null;
            const box = finalBox(frame ? frame.box : [item.x0, item.y0, item.x1, item.y1],
                face ? SETTINGS.faceMargin : SETTINGS.margin, face ? SETTINGS.faceRatio : 0, infos[i].w, infos[i].h);
            if (!box) return;
            const tilt = frame ? frame.tilt : 0;
            try {
                const result = await cropOne(file, box, tilt, frame ? frame.pivot : null);
                if (tilt) noteBy[i].push(file.name + ': oklüzal düzlem ' + Math.abs(tilt).toFixed(1) + '° düzeltildi');
                if (frame && !frame.upper && !frame.lower) noteBy[i].push(file.name + ': ekartör kolu ölçülemedi, modelin kutusu kullanıldı');
                out[i] = result.file;
                cropBy[i] = { name: file.name, slot: item.slot, file: result.file, width: result.width, height: result.height,
                    sig: result.sig, thumb: infos[i].data, bright: infos[i].bright, sharp: infos[i].sharp,
                    score: qualityScore(infos[i]) };
                if (item.note) noteBy[i].push(file.name + ': ' + item.note);
            } catch (error) {
                noteBy[i].push(file.name + ': kırpılamadı (' + error.message + ')');
            }
        }

        const tick = function () {
            say('Yapay zeka kırpma kutularını hesaplıyor… ' + secs(preparedAt) + ' sn (' + answered + '/' + groups.length +
                ' bölüm yanıtladı, ' + finished + '/' + batch.length + ' fotoğraf işlendi)');
        };
        tick();
        const timer = setInterval(tick, 1000);
        try {
            await Promise.all(groups.map(async function (idx) {
                let items;
                try {
                    const reply = await send({
                        type: 'ids-crop',
                        images: idx.map(function (i) { return { index: i + 1, data: infos[i].data }; })
                    });
                    items = reply.items || [];
                } catch (error) {
                    errors.push(error.message);
                    idx.forEach(function (i) {
                        noteBy[i].push(batch[i].name + ': kırpma kutusu alınamadı (' + error.message + '), olduğu gibi yüklenecek');
                        finished++;
                    });
                    return;
                }
                answered++;
                // Yan kareler: sağ/sol tahmini kırpma modelinde güvenilmez (yan çevrilmiş karelerde şaşıyor, 29 Ekim 2026);
                // üst çene ve ön diş yönü güçlü modelden okunur ve sağ/sol bunlardan hesaplanır. Bu okuma diğer
                // karelerin kırpılmasını beklemez.
                const bySlot = function (i) { return items.find(function (it) { return Number(it.index) === i + 1; }); };
                const buccal = idx.filter(function (i) {
                    const it = bySlot(i);
                    return it && /^buccal_/.test(it.slot) && Number(it.confidence) >= SETTINGS.minConfidence;
                });
                const sideWork = (async function () {
                    if (!buccal.length) return;
                    try {
                        const reply = await send({
                            type: 'ids-sides',
                            images: buccal.map(function (i) { return { index: i + 1, data: infos[i].data }; })
                        });
                        (reply.items || []).forEach(function (r) {
                            const i = Number(r.index) - 1;
                            const it = bySlot(i);
                            const side = buccalSide(r.upper_jaw_side, r.incisors_side);
                            if (!it || !side || buccal.indexOf(i) < 0) return;
                            if (side !== it.slot) {
                                noteBy[i].push(batch[i].name + ': sağ/sol yön okumasıyla düzeltildi (' + (side === 'buccal_right' ? 'sağ' : 'sol') + ' bukkal)');
                                it.slot = side;
                            }
                        });
                    } catch (error) {
                        buccal.forEach(function (i) {
                            noteBy[i].push(batch[i].name + ': sağ/sol yön okuması alınamadı (' + error.message + '), kırpma modelinin tahmini kullanıldı');
                        });
                    }
                })();
                await Promise.all(idx.map(async function (i) {
                    if (buccal.indexOf(i) >= 0) await sideWork;
                    return cropLimit(async function () {
                        try { await cropIndex(i, items); } finally { finished++; }
                    });
                }));
            }));
        } finally {
            clearInterval(timer);
        }
        if (errors.length === groups.length) throw new Error(errors[0]);

        const cropItems = cropBy.filter(Boolean);
        return {
            files: out, cropped: cropItems.length, total: batch.length,
            notes: [].concat.apply([], noteBy), items: cropItems,
            timing: { prepare: Math.round((preparedAt - started) / 1000), total: secs(started), groups: groups.length }
        };
    }

    window.idsfyCrop = { cropFiles: cropFiles, finalBox: finalBox, intraoralFrame: intraoralFrame, matchOriginal: matchOriginal,
        matchGroup: matchGroup, buccalSide: buccalSide, qualityScore: qualityScore, SETTINGS: SETTINGS };
})();
