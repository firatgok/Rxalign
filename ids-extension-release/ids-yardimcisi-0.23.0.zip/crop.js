// Fotoğrafları IDS'e bırakmadan önce kırpar (kullanıcı kararı, 21 Ekim 2026). Küçültülmüş kareler
// arka plana (ids-crop) gider; model her kare için yuva ve kırpma kutusu verir; kırpma tarayıcıda
// tuvalde yapılır, klasördeki dosyalar değişmez. Çerçeve kuralları tools/crop-trial sayfasında
// kullanıcıyla denendi: ağız içi = modelin kutusu + %8 pay, en-boy serbest; yüz (profil/önden) =
// pay yok, dikey 2:3 (saçın biraz üstünden yakanın altına). "other" ve düşük güvenli kareler olduğu
// gibi kalır; IDS'in otomatik sıralaması yine kendisi yapar.
(function () {
    'use strict';

    const SETTINGS = {
        maxSide: 1024,        // modele giden karenin uzun kenarı (piksel)
        margin: 8,            // ağız içi pay (%)
        faceMargin: 0,        // yüz payı (%)
        faceRatio: 2 / 3,     // yüz en-boy (genişlik / yükseklik)
        maxImages: 30,        // tek istekte en çok bu kadar kare; fazlası olduğu gibi kalır
        minConfidence: 0.4,   // altında kırpılmaz
        quality: 0.92         // kırpılmış JPEG kalitesi
    };
    const FACE = /^(profile|frontal)_/;
    const NAMES = {
        profile_repose: 'profil', frontal_repose: 'önden', frontal_smiling: 'gülümseme',
        occlussal_upper: 'üst oklüzal', occlussal_lower: 'alt oklüzal', buccal_right: 'sağ bukkal',
        buccal_left: 'sol bukkal', labial_anterior: 'ağız içi önden', other: 'diğer'
    };

    function send(message) {
        return new Promise(function (resolve, reject) {
            if (!chrome.runtime || !chrome.runtime.id) {
                return reject(new Error('Eklenti güncellendi; bu sayfayı yenileyin (F5).'));
            }
            chrome.runtime.sendMessage(message, function (reply) {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!reply || !reply.ok) return reject(new Error(reply ? reply.error : 'yanıt yok'));
                resolve(reply);
            });
        });
    }

    // EXIF yönü uygulanmış kare: model kutuyu bu haliyle verir, kırpma da aynı haliyle yapılır.
    function bitmapOf(file) {
        return createImageBitmap(file, { imageOrientation: 'from-image' });
    }

    async function thumbnail(file) {
        const bitmap = await bitmapOf(file);
        try {
            const scale = Math.min(1, SETTINGS.maxSide / Math.max(bitmap.width, bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(bitmap.width * scale));
            canvas.height = Math.max(1, Math.round(bitmap.height * scale));
            canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
            return { w: bitmap.width, h: bitmap.height, data: canvas.toDataURL('image/jpeg', 0.85).split(',')[1] };
        } finally {
            bitmap.close();
        }
    }

    // Pay ve en-boy uygulanmış son kutu (kesirler). Görüntü dışına taşarsa kaydırılır, sığmazsa kırpılır.
    function finalBox(box, marginPct, ratio, w, h) {
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        [x0, y0, x1, y1] = [x0, y0, x1, y1].map(function (v) { return Math.min(1, Math.max(0, Number(v) || 0)); });
        if (x1 <= x0 || y1 <= y0) return null;
        const m = marginPct / 100;
        const bw = x1 - x0, bh = y1 - y0;
        x0 -= bw * m; x1 += bw * m; y0 -= bh * m; y1 += bh * m;
        if (ratio) {
            const pw = (x1 - x0) * w, ph = (y1 - y0) * h;
            if (pw / ph < ratio) {
                const nw = ph * ratio, cx = (x0 + x1) / 2 * w;
                x0 = (cx - nw / 2) / w; x1 = (cx + nw / 2) / w;
            } else {
                const nh = pw / ratio, cy = (y0 + y1) / 2 * h;
                y0 = (cy - nh / 2) / h; y1 = (cy + nh / 2) / h;
            }
        }
        if (x0 < 0) { x1 -= x0; x0 = 0; }
        if (y0 < 0) { y1 -= y0; y0 = 0; }
        if (x1 > 1) { x0 -= x1 - 1; x1 = 1; }
        if (y1 > 1) { y0 -= y1 - 1; y1 = 1; }
        return [Math.max(0, x0), Math.max(0, y0), Math.min(1, x1), Math.min(1, y1)];
    }

    function toBlob(canvas) {
        return new Promise(function (resolve) { canvas.toBlob(resolve, 'image/jpeg', SETTINGS.quality); });
    }

    async function cropOne(file, box) {
        const bitmap = await bitmapOf(file);
        try {
            const sx = Math.round(box[0] * bitmap.width), sy = Math.round(box[1] * bitmap.height);
            const sw = Math.max(1, Math.round((box[2] - box[0]) * bitmap.width));
            const sh = Math.max(1, Math.round((box[3] - box[1]) * bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = sw;
            canvas.height = sh;
            canvas.getContext('2d').drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
            const blob = await toBlob(canvas);
            if (!blob) throw new Error('kırpılmış görüntü üretilemedi');
            const name = file.name.replace(/\.[^.]+$/, '') + '.jpg';
            return { file: new File([blob], name, { type: 'image/jpeg', lastModified: file.lastModified }), width: sw, height: sh };
        } finally {
            bitmap.close();
        }
    }

    // files: File dizisi; progress(metin) ilerlemeyi bildirir.
    // Dönüş: { files (aynı sırada, kırpılanlar yeni File), cropped, total, notes[] }.
    async function cropFiles(files, progress) {
        const say = progress || function () {};
        const batch = files.slice(0, SETTINGS.maxImages);
        const infos = [];
        for (let i = 0; i < batch.length; i++) {
            say('Fotoğraflar kırpma için hazırlanıyor… (' + (i + 1) + '/' + batch.length + ')');
            infos.push(await thumbnail(batch[i]));
        }
        say(batch.length + ' fotoğraf için kırpma kutuları isteniyor…');
        const reply = await send({
            type: 'ids-crop',
            images: infos.map(function (info, i) { return { index: i + 1, data: info.data }; })
        });
        const items = reply.items || [];
        const out = files.slice();
        const notes = [];
        let cropped = 0;
        for (let i = 0; i < batch.length; i++) {
            const file = batch[i];
            const item = items.find(function (it) { return Number(it.index) === i + 1; });
            if (!item || item.slot === 'other' || !(Number(item.confidence) >= SETTINGS.minConfidence)) {
                if (item && item.note) notes.push(file.name + ': ' + item.note);
                continue;
            }
            const face = FACE.test(item.slot);
            const box = finalBox([item.x0, item.y0, item.x1, item.y1],
                face ? SETTINGS.faceMargin : SETTINGS.margin, face ? SETTINGS.faceRatio : 0, infos[i].w, infos[i].h);
            if (!box) continue;
            say('Kırpılıyor: ' + file.name + ' (' + (NAMES[item.slot] || item.slot) + ')…');
            try {
                out[i] = (await cropOne(file, box)).file;
                cropped++;
                if (item.note) notes.push(file.name + ': ' + item.note);
            } catch (error) {
                notes.push(file.name + ': kırpılamadı (' + error.message + ')');
            }
        }
        return { files: out, cropped: cropped, total: batch.length, notes: notes };
    }

    window.idsfyCrop = { cropFiles: cropFiles, finalBox: finalBox, SETTINGS: SETTINGS };
})();
