// Fotoğrafları IDS'e bırakmadan önce kırpar (kullanıcı kararı, 21 Ekim 2026). Küçültülmüş kareler
// arka plana (ids-crop) gider; model her kare için yuva ve kırpma kutusu verir; kırpma tarayıcıda
// tuvalde yapılır, klasördeki dosyalar değişmez. Çerçeve kuralları tools/crop-trial sayfasında
// kullanıcıyla denendi: yüz (profil/önden) = pay yok, dikey 2:3 (saçın biraz üstünden yakanın altına);
// ön ve yan ağız içi = modelin ölçümlerinden hesaplanan çerçeve (intraoralFrame); oklüzal = modelin kutusu.
// "other" ve düşük güvenli kareler olduğu gibi kalır; IDS'in otomatik sıralaması yine kendisi yapar.
(function () {
    'use strict';

    const SETTINGS = {
        maxSide: 1024,        // modele giden karenin uzun kenarı (piksel)
        margin: 0,            // ağız içi pay (%): çerçeveyi ekartör kolları belirlediği için pay yok (kullanıcı, 29 Ekim 2026)
        retractorKeep: 0.3,   // ekartör kolunun karede kalan payı (0.3 = kolun %30'u içeride; yarıdan indirildi, kullanıcı 29 Ekim 2026: dudak biraz daha kesilsin)
        balance: 1.4,         // oklüzal düzlemin üstü/altı bu orandan dengesizse uzun tarafta dudak kıvrımı esas alınır
        teethPad: 0.015,      // diş sınırı emniyeti, dikey (görüntü yüksekliğinin kesri)
        teethPadX: 0.01,      // diş sınırı emniyeti, yatay (görüntü genişliğinin kesri)
        archAspectMin: 0.55,  // oklüzal diş sırası kutusunun piksel en-boy oranı bu aralığın dışındaysa kare oklüzal sayılmaz
        archAspectMax: 2.0,
        maxAspect: 2.0,       // ağız içi önden/yan kırpmada en/boy en çok bu kadar (dişleri saran yatay şerit olmasın): boy merkez etrafında genişletilir
        minOutW: 1000,        // çıkış kırpmasının asgari genişliği/yüksekliği (piksel); IDS 1000x392'yi kabul etti, 800x314'e ünlem verdi
        minOutH: 500,
        roomH: 1.5,           // ağız içi önden/yan karede çerçeve yüksekliği en az diş yüksekliğinin bu katı (dişleri saran dar şerit olmasın)
        roomW: 1.15,          // yalnız önden karede genişlik en az diş genişliğinin bu katı (yan karede çerçeve dişleri yatayda sarar: C ucu)
        cropEffort: 'medium',   // model çağrılarının effort değeri (low | medium | high): düşük = hızlı
        sidesEffort: 'medium',
        archEffort: 'medium',
        rotateAtCrop: true,   // yön kırpma sırasında okunur ve uygulanır (kare IDS'e dik yüklenir)
        poseModel: 'sonnet',  // yön okuması: bağımsız tek fotoğraflık çağrılar; kararsızsa Opus hakem
        poseEffort: 'medium',
        poseArbiterEffort: 'high',
        poseParallel: 6,
        archModel: 'sonnet',  // diş sırası kutusu okuması: opus | sonnet (13 karelik denemede Opus 10-21 sn, Sonnet 2-4 sn; kutu kalitesi aynı)
        hedgeMs: 20000,           // >0: bu kadar ms içinde yanıtlanmayan model çağrısına ikinci istek açılır, ilk gelen alınır (0 = kapalı)
        minTilt: 0.3,         // bunun altındaki oklüzal düzlem eğimi düzeltilmez (derece)
        maxTilt: 20,          // oklüzal düzlem düzeltmesi en çok bu kadar derece
        occlusalMargin: 10,   // oklüzal: diş sınırının her kenarına eklenen pay (%)
        faceMargin: 10,       // yüz payı (%): kutunun her kenarına eklenir (kullanıcı, 29 Ekim 2026: yüzler çok kırpılıyor, biraz genişlet)
        faceRatio: 2 / 3,     // yüz en-boy (genişlik / yükseklik)
        maxImages: 80,        // bir klasörden en çok bu kadar kare kırpılır; fazlası olduğu gibi kalır (30 iken 34 karelik klasörde dosya adına göre son kareler, yani oklüzaller, hiç işlenmiyordu: 30 Ekim 2026)
        groupSize: 6,         // model her istekte en çok bu kadar kareye bakar; gruplar aynı anda sorulur
        prepareParallel: 3,   // aynı anda çözülen tam boyutlu kare sayısı (küçük kare hazırlığı)
        cropParallel: 2,      // aynı anda kırpılan tam boyutlu kare sayısı
        minConfidence: 0.4,   // altında kırpılmaz
        quality: 0.92         // kırpılmış JPEG kalitesi
    };
    const FACE = /^(profile|frontal)_/;
    const INTRAORAL = /^(labial|buccal)_/;
    const NAMES = {
        profile_repose: 'profil', frontal_repose: 'önden', frontal_smiling: 'gülümseme',
        occlussal_upper: 'üst oklüzal', occlussal_lower: 'alt oklüzal', buccal_right: 'sağ bukkal',
        buccal_left: 'sol bukkal', labial_anterior: 'ağız içi önden', other: 'diğer'
    };

    function num(v) { const n = Number(v); return isFinite(n) ? n : 0; }

    // Model çağrısı: hedgeMs > 0 ise bu süre içinde yanıtlanmayan çağrıya ikinci istek açılır ve ilk başarılı yanıt alınır
    // (aynı iş bazen 9 sn, bazen 50 sn sürüyor; kuyruk gecikmesini keser, yalnız yavaş çağrılarda ek maliyet).
    function sendHedged(message) {
        if (!(SETTINGS.hedgeMs > 0)) return send(message);
        return new Promise(function (resolve, reject) {
            let done = false, failures = 0, started = 1;
            const finish = function (ok, value) {
                if (done) return;
                if (ok) { done = true; clearTimeout(timer); resolve(value); return; }
                failures++;
                if (failures >= started) { done = true; clearTimeout(timer); reject(value); }
            };
            const run = function () { send(message).then(function (r) { finish(true, r); }, function (e) { finish(false, e); }); };
            const timer = setTimeout(function () { if (!done) { started++; run(); } }, SETTINGS.hedgeMs);
            run();
        });
    }

    function send(message) {
        return new Promise(function (resolve, reject) {
            if (!chrome.runtime || !chrome.runtime.id) {
                return reject(new Error('Eklenti güncellendi; bu sayfayı yenileyin (F5).'));
            }
            chrome.runtime.sendMessage(message, function (reply) {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!reply || !reply.ok) return reject(new Error(reply ? reply.error : 'yanıt yok'));
                resolve(reply);
            });
        });
    }

    // EXIF yönü uygulanmış kare: model kutuyu bu haliyle verir, kırpma da aynı haliyle yapılır.
    function bitmapOf(file) {
        return createImageBitmap(file, { imageOrientation: 'from-image' });
    }

    // Aynı görünümün tekrar çekimlerini karşılaştırmak için: 256 piksellik gri kareden ortalama parlaklık (0-255)
    // ve netlik (Laplace varyansı). Kıyas yalnızca aynı görünümün kareleri arasında anlamlıdır.
    function qualityOf(source) {
        const w = 256;
        const h = Math.max(8, Math.round(w * source.height / source.width));
        const c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        const ctx = c.getContext('2d');
        ctx.drawImage(source, 0, 0, w, h);
        const px = ctx.getImageData(0, 0, w, h).data;
        const gray = new Float32Array(w * h);
        let sum = 0;
        for (let i = 0; i < gray.length; i++) {
            gray[i] = px[i * 4] * 0.299 + px[i * 4 + 1] * 0.587 + px[i * 4 + 2] * 0.114;
            sum += gray[i];
        }
        let lap = 0, lap2 = 0, n = 0;
        for (let y = 1; y < h - 1; y++) {
            for (let x = 1; x < w - 1; x++) {
                const i = y * w + x;
                const v = 4 * gray[i] - gray[i - 1] - gray[i + 1] - gray[i - w] - gray[i + w];
                lap += v;
                lap2 += v * v;
                n++;
            }
        }
        const mean = lap / n;
        return { bright: sum / gray.length, sharp: lap2 / n - mean * mean };
    }

    // Aday sıralaması: pozlaması dengeli (ne karanlık ne patlamış) ve net olan önde.
    function qualityScore(it) {
        const exposure = Math.max(0.05, 1 - Math.abs((Number(it.bright) || 0) - 125) / 125);
        return (Number(it.sharp) || 0) * exposure;
    }

    async function thumbnail(file) {
        const bitmap = await bitmapOf(file);
        try {
            const scale = Math.min(1, SETTINGS.maxSide / Math.max(bitmap.width, bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(bitmap.width * scale));
            canvas.height = Math.max(1, Math.round(bitmap.height * scale));
            canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
            const q = qualityOf(canvas);
            return { w: bitmap.width, h: bitmap.height, data: canvas.toDataURL('image/jpeg', 0.85).split(',')[1],
                bright: q.bright, sharp: q.sharp };
        } finally {
            bitmap.close();
        }
    }

    // Kutu çok yatay ise (en/boy > maxAspect) boyu merkez etrafında genişletilir, çok küçükse (piksel) merkez etrafında büyütülür;
    // görüntü sınırında kaydırılır. Kutu kesirlerle, w/h ham kare pikselleridir.
    function relaxBox(box, w, h, maxAspect, minW, minH) {
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        const grow = function (lo, hi, want) {
            let a = lo, b = hi;
            if (b - a >= want) return [a, b];
            const c = (a + b) / 2;
            a = c - want / 2; b = c + want / 2;
            if (a < 0) { b -= a; a = 0; }
            if (b > 1) { a -= b - 1; b = 1; }
            return [Math.max(0, a), Math.min(1, b)];
        };
        if (maxAspect > 0 && (x1 - x0) * w / ((y1 - y0) * h) > maxAspect) {
            const r = grow(y0, y1, (x1 - x0) * w / maxAspect / h);
            y0 = r[0]; y1 = r[1];
        }
        if (minW > 0 && (x1 - x0) * w < minW) { const r = grow(x0, x1, minW / w); x0 = r[0]; x1 = r[1]; }
        if (minH > 0 && (y1 - y0) * h < minH) { const r = grow(y0, y1, minH / h); y0 = r[0]; y1 = r[1]; }
        return [x0, y0, x1, y1];
    }

    // Pay ve en-boy uygulanmış son kutu (kesirler). Görüntü dışına taşarsa kaydırılır, sığmazsa kırpılır.
    function finalBox(box, marginPct, ratio, w, h) {
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        [x0, y0, x1, y1] = [x0, y0, x1, y1].map(function (v) { return Math.min(1, Math.max(0, Number(v) || 0)); });
        if (x1 <= x0 || y1 <= y0) return null;
        const m = marginPct / 100;
        const bw = x1 - x0, bh = y1 - y0;
        x0 -= bw * m; x1 += bw * m; y0 -= bh * m; y1 += bh * m;
        if (ratio) {
            const pw = (x1 - x0) * w, ph = (y1 - y0) * h;
            if (pw / ph < ratio) {
                const nw = ph * ratio, cx = (x0 + x1) / 2 * w;
                x0 = (cx - nw / 2) / w; x1 = (cx + nw / 2) / w;
            } else {
                const nh = pw / ratio, cy = (y0 + y1) / 2 * h;
                y0 = (cy - nh / 2) / h; y1 = (cy + nh / 2) / h;
            }
        }
        if (x0 < 0) { x1 -= x0; x0 = 0; }
        if (y0 < 0) { y1 -= y0; y0 = 0; }
        if (x1 > 1) { x0 -= x1 - 1; x1 = 1; }
        if (y1 > 1) { y0 -= y1 - 1; y1 = 1; }
        return [Math.max(0, x0), Math.max(0, y0), Math.min(1, x1), Math.min(1, y1)];
    }

    // Ön ve yan ağız içi kare: çerçeve modelin kutusundan değil ölçümlerinden hesaplanır (kullanıcı ince
    // ayarı, 29 Ekim 2026: model "kolun yarısı içeride" kutusunu tutturamıyordu; ölçüm + hesap daha güvenilir).
    //   plane_x0..plane_y1 : oklüzal düzlemin iki ucu → eğim (sağa doğru aşağı = pozitif); görüntü kutu
    //                        merkezi (pivot) etrafında -eğim kadar döndürülür, düzlem yere paralel olur.
    //   arms[]             : ekartör kolu {x, top, bottom}; üst/alt kol düzleme göre ayrılır (kare ters
    //                        olsa da çalışır); kesme noktası kolun dişe bakan kenarından retractorKeep
    //                        oranında dışarıda; döndürülmüş karede y alınır, üst/alt kenar ortalamadır.
    //   lip_upper_y/lower  : dudak-dişeti kıvrımı; düzlemin üstü/altı çok dengesizse (balance) uzun tarafta
    //                        ekartör yerine bu kıvrım kenar olur (kullanıcı, 29 Ekim 2026).
    //   c_left/right_x     : C ekartörün iç bükey ucu → o yanın kenarı (C'nin sırtı ve yanak dışarıda).
    //   far_left/right_x   : karşı ekartörün dişe bakan kenarı → o yan dişe yaklaşır, karşı ekartör dışarıda.
    //   teeth_*            : diş tacı sınırı → emniyet, hiçbir diş kesilmez.
    // Döndürme köşeleri görüntü dışına taşırırsa o yan içeri çekilir (siyah köşe kalmasın).
    // Düzlem 45°'den eğikse (kare yan duruyor) ölçümlere güvenilmez, modelin kutusu olduğu gibi kalır.
    // w, h: görüntü boyutu (piksel). Dönüş: box döndürülmüş karede kesirler; tilt derece; pivot kesir.
    function intraoralFrame(item, w, h) {
        const box = [num(item.x0), num(item.y0), num(item.x1), num(item.y1)];
        const pivot = [(box[0] + box[2]) / 2, (box[1] + box[3]) / 2];
        let p0 = [num(item.plane_x0), num(item.plane_y0)], p1 = [num(item.plane_x1), num(item.plane_y1)];
        if (p0[0] > p1[0]) { const t = p0; p0 = p1; p1 = t; }
        const dx = (p1[0] - p0[0]) * w, dy = (p1[1] - p0[1]) * h;
        const hasPlane = Math.hypot(dx, dy) > 0.05 * Math.min(w, h);
        const angle = hasPlane ? Math.atan2(dy, dx) * 180 / Math.PI : 0;
        const sideways = Math.abs(angle) > 45;
        let tilt = sideways ? 0 : angle;
        if (Math.abs(tilt) < SETTINGS.minTilt || Math.abs(tilt) > SETTINGS.maxTilt) tilt = 0;
        const rad = -tilt * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
        const px = pivot[0] * w, py = pivot[1] * h;
        // Noktanın döndürülmüş karedeki x'i / y'si (kesir) ve döndürülmüş karedeki noktanın orijinalde içeride olup olmadığı.
        const rotX = function (x, y) { const X = x * w - px, Y = y * h - py; return (X * cos - Y * sin + px) / w; };
        const rotY = function (x, y) { const X = x * w - px, Y = y * h - py; return (X * sin + Y * cos + py) / h; };
        const inside = function (x, y) {
            const X = x * w - px, Y = y * h - py;
            const ox = (px + X * cos + Y * sin) / w, oy = (py - X * sin + Y * cos) / h;
            return ox >= 0 && ox <= 1 && oy >= 0 && oy <= 1;
        };
        const planeY = function (x) {
            return hasPlane ? p0[1] + (x - p0[0]) * (p1[1] - p0[1]) / (p1[0] - p0[0]) : pivot[1];
        };
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        const arms = [];
        const used = { lip: '', sides: [] };
        let teeth = null, lips = null, sides = null;
        if (!sideways) {
            // Üst/alt kenar: ekartör kollarının kesme noktaları (döndürülmüş karede, ortalama).
            (Array.isArray(item.arms) ? item.arms : []).forEach(function (arm) {
                const x = num(arm.x), top = num(arm.top), bottom = num(arm.bottom), keep = SETTINGS.retractorKeep;
                if (!(bottom > top) || bottom - top > 0.25) return;
                const upper = (top + bottom) / 2 < planeY(x);
                const cut = upper ? bottom - keep * (bottom - top) : top + keep * (bottom - top);
                arms.push({ x: x, top: top, bottom: bottom, cut: cut, upper: upper, y: rotY(x, cut) });
            });
            const mean = function (a) { return a.reduce(function (s, v) { return s + v; }, 0) / a.length; };
            const ups = arms.filter(function (a) { return a.upper; }).map(function (a) { return a.y; });
            const lows = arms.filter(function (a) { return !a.upper; }).map(function (a) { return a.y; });
            if (ups.length) y0 = mean(ups);
            if (lows.length) y1 = mean(lows);
            // Denge: düzlemin üstü ile altı çok dengesizse uzun tarafta ekartör yerine dudak-dişeti kıvrımı.
            const lu = num(item.lip_upper_y), ll = num(item.lip_lower_y);
            lips = [lu, ll];
            if (hasPlane) {
                const cx = (p0[0] + p1[0]) / 2;
                const pc = rotY(cx, planeY(cx));
                const up = pc - y0, down = y1 - pc;
                if (up > 0 && down > 0) {
                    if (up > down * SETTINGS.balance && lu > 0) {
                        const yl = rotY(cx, lu);
                        if (yl > y0 && yl < pc) { y0 = yl; used.lip = 'üst'; }
                    } else if (down > up * SETTINGS.balance && ll > 0) {
                        const yl = rotY(cx, ll);
                        if (yl < y1 && yl > pc) { y1 = yl; used.lip = 'alt'; }
                    }
                }
            }
            // Yanlar: C'nin iç bükey ucu (C'nin sırtı dışarıda), karşı ekartörün dişe bakan kenarı (karşı ekartör dışarıda).
            sides = { cl: num(item.c_left_x), fl: num(item.far_left_x), cr: num(item.c_right_x), fr: num(item.far_right_x) };
            [[sides.cl, 'sol C'], [sides.fl, 'sol karşı ekartör']].forEach(function (c) {
                if (c[0] > 0 && c[0] < 1) { const r = rotX(c[0], pivot[1]); if (r > x0) { x0 = r; used.sides.push(c[1]); } }
            });
            [[sides.cr, 'sağ C'], [sides.fr, 'sağ karşı ekartör']].forEach(function (c) {
                if (c[0] > 0 && c[0] < 1) { const r = rotX(c[0], pivot[1]); if (r < x1) { x1 = r; used.sides.push(c[1]); } }
            });
            // Diş emniyeti: hiçbir diş kesilmez.
            const tt = num(item.teeth_top), tb = num(item.teeth_bottom), tl = num(item.teeth_left), tr = num(item.teeth_right);
            if (tb > tt) {
                teeth = [tt, tb];
                y0 = Math.min(y0, rotY(pivot[0], tt) - SETTINGS.teethPad);
                y1 = Math.max(y1, rotY(pivot[0], tb) + SETTINGS.teethPad);
            }
            if (tr > tl) {
                x0 = Math.min(x0, rotX(tl, pivot[1]) - SETTINGS.teethPadX);
                x1 = Math.max(x1, rotX(tr, pivot[1]) + SETTINGS.teethPadX);
            }
            // Önden ağız içi: orta hat (üst orta kesiciler arası; ölçülemezse diş sınırının ortası) ortada, dişlerle çerçeve
            // arasında sağ ve solda eşit mesafe. Çerçeve orta hat etrafında simetrik yapılır (geniş olan yan esas alınır, diş
            // kesilmez); orta hat görüntü kenarına yakınsa ya da diş sığmıyorsa simetri uygulanmaz.
            let symmetric = false;
            if (/^labial_/.test(item.slot || '')) {
                const midRaw = num(item.midline_x);
                const c = midRaw > 0 && midRaw < 1 ? rotX(midRaw, pivot[1]) : (tr > tl ? rotX((tl + tr) / 2, pivot[1]) : (x0 + x1) / 2);
                let hw = Math.max(c - x0, x1 - c);
                const fits = Math.min(c, 1 - c);
                const need = tr > tl ? Math.max(c - rotX(tl, pivot[1]), rotX(tr, pivot[1]) - c) + SETTINGS.teethPadX : 0;
                if (c > 0 && c < 1 && fits >= need && fits > 0.1) {
                    hw = Math.min(hw, fits);
                    x0 = c - hw;
                    x1 = c + hw;
                    symmetric = true;
                }
            }
            // Döndürme köşeleri görüntü dışına taşırırsa yanlar içeri çekilir (siyah köşe kalmasın; en çok %25); simetrik
            // çerçevede iki yan birlikte çekilir.
            if (tilt) {
                const limit0 = x0 + (x1 - x0) * 0.25, limit1 = x1 - (x1 - x0) * 0.25;
                if (symmetric) {
                    while (x0 < limit0 && !(inside(x0, y0) && inside(x0, y1) && inside(x1, y0) && inside(x1, y1))) { x0 += 0.003; x1 -= 0.003; }
                } else {
                    while (x0 < limit0 && !(inside(x0, y0) && inside(x0, y1))) x0 += 0.003;
                    while (x1 > limit1 && !(inside(x1, y0) && inside(x1, y1))) x1 -= 0.003;
                }
            }
        }
        if (!(y1 - y0 > 0.1) || !(x1 - x0 > 0.2)) { x0 = box[0]; y0 = box[1]; x1 = box[2]; y1 = box[3]; }
        // Emniyet: ölçümler (kol, C ucu, dudak kıvrımı) yanlış yere düştüyse çerçeve dişleri neredeyse tam sarar. Diş sınırı geçerliyse
        // çerçeve diş boyunun/enininin en az roomH/roomW katı olmalı: önce modelin kutusu denenir, o da dar ise diş kutusu merkez alınarak
        // genişletilir (görüntü sınırında kaydırılır).
        if (!sideways) {
            const ttop = num(item.teeth_top), tbot = num(item.teeth_bottom), tlef = num(item.teeth_left), trig = num(item.teeth_right);
            if (tbot > ttop && trig > tlef) {
                const minH = (tbot - ttop) * SETTINGS.roomH, minW = /^labial_/.test(item.slot || '') ? (trig - tlef) * SETTINGS.roomW : 0;
                if (y1 - y0 < minH || x1 - x0 < minW) {
                    const big = box[3] - box[1] >= minH && box[2] - box[0] >= minW;
                    if (big) {
                        x0 = Math.min(box[0], tlef - 0.01); y0 = Math.min(box[1], ttop - 0.015);
                        x1 = Math.max(box[2], trig + 0.01); y1 = Math.max(box[3], tbot + 0.015);
                        used.room = 'model kutusu';
                    } else {
                        const cx = (tlef + trig) / 2, cy = (ttop + tbot) / 2;
                        const hw = Math.max(minW, (trig - tlef) + 0.02) / 2, hh = Math.max(minH, (tbot - ttop) + 0.03) / 2;
                        x0 = cx - hw; x1 = cx + hw; y0 = cy - hh; y1 = cy + hh;
                        if (x0 < 0) { x1 -= x0; x0 = 0; }
                        if (x1 > 1) { x0 -= x1 - 1; x1 = 1; }
                        if (y0 < 0) { y1 -= y0; y0 = 0; }
                        if (y1 > 1) { y0 -= y1 - 1; y1 = 1; }
                        used.room = 'diş kutusu genişletildi';
                    }
                    x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(1, x1); y1 = Math.min(1, y1);
                }
            }
        }
        return {
            box: [x0, y0, x1, y1], tilt: tilt, angle: angle, pivot: pivot,
            plane: hasPlane ? [p0[0], p0[1], p1[0], p1[1]] : null, teeth: teeth, lips: lips, sides: sides, arms: arms, used: used,
            upper: arms.filter(function (a) { return a.upper; }).length,
            lower: arms.filter(function (a) { return !a.upper; }).length
        };
    }

    // Oklüzal: modelin kutusu gevşek kalıyordu (yüz, çene, ekartör kadrajda); çerçeve ölçülen diş sınırından kurulur.
    // Ölçüm yoksa ya da anlamsızsa null (modelin kutusu kullanılır).
    function occlusalBox(item) {
        const l = num(item.teeth_left), r = num(item.teeth_right), t = num(item.teeth_top), b = num(item.teeth_bottom);
        if (!(r - l > 0.1 && b - t > 0.1) || l < 0 || t < 0 || r > 1 || b > 1) return null;
        return [l, t, r, b];
    }

    // Yan duran (dik tutulmuş) kare: model ölçümleri ve kutuyu düzlemi yatay yapan döndürülmüş karede verir (view_rotation 90/270);
    // çerçeve orada hesaplanır, sonuç ham kareye geri çevrilir. Çıkan kutu ham kare eksenlerindedir; eğim (tilt) aynı yönde ve
    // pivot ham karede olduğundan cropOne değişmez. Ham kareye ait olmayan ayrıntılar (düzlem, kollar vb.) boşaltılır.
    function intraoralFrameAny(item, w, h) {
        const rot = Number(item.view_rotation) || 0;
        if (rot !== 90 && rot !== 270) return intraoralFrame(item, w, h);
        const f = intraoralFrame(item, h, w);
        const back = function (x, y) { return rot === 90 ? [y, 1 - x] : [1 - y, x]; };
        const a = back(f.box[0], f.box[1]);
        const b = back(f.box[2], f.box[3]);
        f.box = [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1])];
        f.pivot = back(f.pivot[0], f.pivot[1]);
        f.plane = null; f.teeth = null; f.lips = null; f.sides = null; f.arms = [];
        f.rotated = rot;
        return f;
    }

    function toBlob(canvas) {
        return new Promise(function (resolve) { canvas.toBlob(resolve, 'image/jpeg', SETTINGS.quality); });
    }

    // 16×16 gri imza: IDS yuvasındaki önizlemenin hangi kırpılmış dosya olduğunu bulmak için.
    const SIG = 16;
    function signatureOf(source, w, h) {
        const canvas = document.createElement('canvas');
        canvas.width = SIG;
        canvas.height = SIG;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(source, 0, 0, w, h, 0, 0, SIG, SIG);
        const px = ctx.getImageData(0, 0, SIG, SIG).data;
        const out = new Array(SIG * SIG);
        for (let i = 0; i < out.length; i++) out[i] = px[i * 4] * 0.299 + px[i * 4 + 1] * 0.587 + px[i * 4 + 2] * 0.114;
        return out;
    }

    function distance(a, b) {
        let sum = 0;
        for (let i = 0; i < a.length; i++) sum += Math.abs(a[i] - b[i]);
        return sum / a.length;
    }

    // Önizleme (IDS'in küçülttüğü yüklenmiş kare) hangi kırpılmış dosyaya ait? En iyi eşleşmeye yakın (+8) olanların
    // hepsi döner: benzer çekimler (ikizler) imzayla ayırt edilemez; hepsi aynı hedef yuvadaysa hangisi olduğu önemsizdir.
    // Hiçbiri yeterince yakın değilse boş dizi.
    async function matchGroup(blob, items) {
        if (!items || !items.length) return [];
        const bitmap = await createImageBitmap(blob);
        try {
            const sig = signatureOf(bitmap, bitmap.width, bitmap.height);
            const ranked = items.filter(function (it) { return it.sig; })
                .map(function (it) { return { item: it, d: distance(sig, it.sig) }; })
                .sort(function (a, b) { return a.d - b.d; });
            if (!ranked.length || ranked[0].d > 20) return [];
            return ranked.filter(function (r) { return r.d < ranked[0].d + 8; }).map(function (r) { return r.item; });
        } finally {
            bitmap.close();
        }
    }

    // Belirsizse (benzer çekimler) null.
    async function matchOriginal(blob, items) {
        const group = await matchGroup(blob, items);
        return group.length === 1 ? group[0] : null;
    }

    // Ham karede üst çenenin ve ön dişlerin yönünden ağız içi yan karenin yanı: üst çene yukarı gelecek şekilde
    // döndürülünce ön dişler sağdaysa sağ bukkal, soldaysa sol bukkal (kliniğin kuralı; fotoğraflar aynasız çekilir).
    // Belirsizse null.
    const SIDE_DEG = { top: 0, right: 90, bottom: 180, left: 270 };
    function buccalSide(upper, incisors) {
        const u = SIDE_DEG[upper];
        const n = SIDE_DEG[incisors];
        if (u === undefined || n === undefined) return null;
        const after = (((n - u) % 360) + 360) % 360;
        return after === 90 ? 'buccal_right' : after === 270 ? 'buccal_left' : null;
    }

    // ---------- Yön (kırpma sırasında) ----------
    const OPPOSITE = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' };
    function axisOf(side) { return side === 'top' || side === 'bottom' ? 'v' : side === 'left' || side === 'right' ? 'h' : null; }
    function turn360(d) { return ((d % 360) + 360) % 360; }

    // Okuma kendi içinde tutarlı mı? Görünüme göre gerekli alanlar dolu; ön diş ve azı dişi karşı uçlarda; yan karede üst çene dişlerin
    // sırasına dik eksendedir (diş sırası yatayken üst çene üstte/altta).
    function poseValid(r) {
        if (!r) return false;
        const known = function (s) { return SIDE_DEG[s] !== undefined; };
        if (r.view === 'frontal') return known(r.upper_jaw_side);
        if (r.view === 'buccal') {
            if (!known(r.upper_jaw_side) || !known(r.incisors_side)) return false;
            if (axisOf(r.upper_jaw_side) === axisOf(r.incisors_side)) return false;
            return !known(r.molars_side) || r.molars_side === OPPOSITE[r.incisors_side];
        }
        if (r.view === 'occlusal') {
            if (!known(r.incisors_side) || (r.arch !== 'upper' && r.arch !== 'lower')) return false;
            // Damak/dil ipucu çeneyle çelişemez (damak = üst, dil = alt).
            if ((r.behind_teeth === 'palate' && r.arch !== 'upper') || (r.behind_teeth === 'tongue' && r.arch !== 'lower')) return false;
            return !known(r.molars_side) || r.molars_side === OPPOSITE[r.incisors_side];
        }
        return false;
    }

    // İki okuma gerekli alanlarda aynı mı?
    function poseAgree(a, b) {
        if (!a || !b || a.view !== b.view) return false;
        if (a.view === 'frontal') return a.upper_jaw_side === b.upper_jaw_side;
        if (a.view === 'buccal') return a.upper_jaw_side === b.upper_jaw_side && a.incisors_side === b.incisors_side;
        if (a.view === 'occlusal') return a.incisors_side === b.incisors_side && a.arch === b.arch;
        return false;
    }

    // Okumalar (geçerli olanlar) arasından en az ikisi uyuşuyorsa onu döndürür, yoksa null.
    function poseVote(reads) {
        const valid = reads.filter(poseValid);
        for (let a = 0; a < valid.length; a++) {
            for (let b = a + 1; b < valid.length; b++) if (poseAgree(valid[a], valid[b])) return valid[a];
        }
        return null;
    }

    // Kırpılacak yuvaya göre döndürme/ayna hedefi: { rotate, mirror, slot } ya da null (belirsiz). Üst çene yukarı alınır; oklüzalde
    // kesiciler üst arkta yukarı ("n"), alt arkta aşağı ("u") ve her zaman ayna görüntüsü (kliniğin kuralı). Yan karede gerçek yan, üst çene
    // yukarı alınınca ön dişlerin sağda (sağ bukkal) ya da solda (sol bukkal) olmasından gelir.
    function orientTarget(slot, pose) {
        if (!pose || !poseValid(pose)) return null;
        if (/^labial_/.test(slot)) {
            if (pose.view !== 'frontal') return null;
            return { rotate: turn360(-SIDE_DEG[pose.upper_jaw_side]), mirror: false, slot: slot };
        }
        if (/^buccal_/.test(slot)) {
            if (pose.view !== 'buccal') return null;
            const side = buccalSide(pose.upper_jaw_side, pose.incisors_side);
            if (!side) return null;
            return { rotate: turn360(-SIDE_DEG[pose.upper_jaw_side]), mirror: false, slot: side };
        }
        if (/^occlussal_/.test(slot)) {
            if (pose.view !== 'occlusal') return null;
            const upper = pose.arch === 'upper';
            return { rotate: turn360((upper ? 0 : 180) - SIDE_DEG[pose.incisors_side]), mirror: true, slot: upper ? 'occlussal_upper' : 'occlussal_lower' };
        }
        return null;
    }

    // box: kesirler (eğim varsa döndürülmüş karede); tilt: oklüzal düzlemin eğimi (derece, sağa doğru
    // aşağı = pozitif); pivot: döndürme merkezi (kesir). Görüntü pivot etrafında -tilt döndürülüp kutu
    // o karede kesilir (oklüzal düzlem yere paralel olur).
    async function cropOne(file, box, tilt, pivot, orient) {
        const bitmap = await bitmapOf(file);
        try {
            const sx = Math.round(box[0] * bitmap.width), sy = Math.round(box[1] * bitmap.height);
            const sw = Math.max(1, Math.round((box[2] - box[0]) * bitmap.width));
            const sh = Math.max(1, Math.round((box[3] - box[1]) * bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = sw;
            canvas.height = sh;
            const ctx = canvas.getContext('2d');
            if (tilt) {
                const px = (pivot ? pivot[0] : (box[0] + box[2]) / 2) * bitmap.width;
                const py = (pivot ? pivot[1] : (box[1] + box[3]) / 2) * bitmap.height;
                ctx.fillStyle = '#000';
                ctx.fillRect(0, 0, sw, sh);
                ctx.translate(px - sx, py - sy);
                ctx.rotate(-tilt * Math.PI / 180);
                ctx.translate(-px, -py);
                ctx.drawImage(bitmap, 0, 0);
                ctx.setTransform(1, 0, 0, 1, 0, 0);
            } else {
                ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
            }
            // Yön: önce saat yönünde orient.rotate kadar döndürülür, sonra orient.mirror ise sağ-sol aynalanır (IDS menüsündeki sıra).
            let fin = canvas;
            if (orient && (orient.rotate || orient.mirror)) {
                const rot = orient.rotate || 0;
                fin = document.createElement('canvas');
                fin.width = rot % 180 ? sh : sw;
                fin.height = rot % 180 ? sw : sh;
                const g = fin.getContext('2d');
                g.translate(fin.width / 2, fin.height / 2);
                if (orient.mirror) g.scale(-1, 1);
                g.rotate(rot * Math.PI / 180);
                g.drawImage(canvas, -sw / 2, -sh / 2);
            }
            const sig = signatureOf(fin, fin.width, fin.height);
            const blob = await toBlob(fin);
            if (!blob) throw new Error('kırpılmış görüntü üretilemedi');
            const name = file.name.replace(/\.[^.]+$/, '') + '.jpg';
            return { file: new File([blob], name, { type: 'image/jpeg', lastModified: file.lastModified }), width: fin.width, height: fin.height, sig: sig };
        } finally {
            bitmap.close();
        }
    }

    // En çok `limit` iş aynı anda çalışır (tam boyutlu kareler bellekte büyüktür).
    function limiter(limit) {
        let active = 0;
        const queue = [];
        const next = function () {
            if (active >= limit || !queue.length) return;
            active++;
            const job = queue.shift();
            job.fn().then(job.resolve, job.reject).then(function () { active--; next(); });
        };
        return function (fn) {
            return new Promise(function (resolve, reject) { queue.push({ fn: fn, resolve: resolve, reject: reject }); next(); });
        };
    }

    // files: File dizisi; progress(metin) ilerlemeyi bildirir.
    // Dönüş: { files (aynı sırada, kırpılanlar yeni File), cropped, total, notes[], items[], timing }.
    // Süre: küçük kareler paralel hazırlanır; fotoğraflar groupSize'lık gruplara bölünüp model aynı anda
    // sorulur (her kare tek başına değerlendirilir, süre en uzun grubun süresi kadar olur) ve bir grup
    // yanıtlayınca o grubun kareleri hemen kırpılır.
    async function cropFiles(files, progress) {
        const say = progress || function () {};
        const started = Date.now();
        const secs = function (from) { return Math.round((Date.now() - from) / 1000); };
        const batch = files.slice(0, SETTINGS.maxImages);

        let prepared = 0;
        const prepare = limiter(SETTINGS.prepareParallel);
        const infos = await Promise.all(batch.map(function (file) {
            return prepare(async function () {
                const info = await thumbnail(file);
                prepared++;
                say('Fotoğraflar hazırlanıyor… (' + prepared + '/' + batch.length + ')');
                return info;
            });
        }));
        const preparedAt = Date.now();

        const groupCount = Math.max(1, Math.ceil(batch.length / SETTINGS.groupSize));
        const per = Math.ceil(batch.length / groupCount);
        const groups = [];
        for (let g = 0; g < groupCount; g++) {
            const idx = [];
            for (let i = g * per; i < Math.min(batch.length, (g + 1) * per); i++) idx.push(i);
            if (idx.length) groups.push(idx);
        }

        const out = files.slice();
        const noteBy = batch.map(function () { return []; });
        // Kırpılan her kare için: modelin yuvası, kırpılmış dosya, imza ve kırpılmamış küçük kare (yön okuması
        // kırpılmış yerine bu kareden yapılır: burun, çene, ekartör gibi ipuçları kalsın).
        const cropBy = new Array(batch.length);
        const errors = [];
        let answered = 0;
        let finished = 0;
        const cropLimit = limiter(SETTINGS.cropParallel);
        const posePool = limiter(SETTINGS.poseParallel);
        // Yön okumaları: tüm gruplar kırpma yanıtını verip tüm okumalar bitince (poseBarrier) seri içi çoğunluk uygulanır, sonra yönlü kırpma yapılır.
        const poseResults = new Array(batch.length);
        const poseStarted = new Array(batch.length);
        const poseJobPromises = [];
        let groupsPending = groups.length;
        let releasePose;
        const poseBarrier = new Promise(function (resolve) { releasePose = resolve; });
        const consensusPose = function () {
            const buckets = {};
            poseResults.forEach(function (p, i) {
                if (!p || !poseValid(p)) return;
                const key = p.view + '|' + infos[i].w + 'x' + infos[i].h;
                (buckets[key] = buckets[key] || []).push(i);
            });
            Object.keys(buckets).forEach(function (key) {
                const list = buckets[key];
                if (list.length < 3) return;
                const field = poseResults[list[0]].view === 'occlusal' ? 'incisors_side' : 'upper_jaw_side';
                const count = {};
                list.forEach(function (i) { const v = poseResults[i][field]; count[v] = (count[v] || 0) + 1; });
                const best = Object.keys(count).sort(function (a, b) { return count[b] - count[a]; })[0];
                if (count[best] / list.length < 0.6) return;
                list.forEach(function (i) {
                    const p = poseResults[i];
                    if (p[field] === best) return;
                    const fix = { consensus: true };
                    fix[field] = best;
                    fix.molars_side = 'none';
                    poseResults[i] = Object.assign({}, p, fix);
                    noteBy[i].push(batch[i].name + ': yön, aynı çekim serisinin çoğunluğuna (' + count[best] + '/' + list.length + ') uydurularak düzeltildi');
                });
            });
        };
        const groupDone = function () {
            groupsPending--;
            if (groupsPending === 0) {
                Promise.all(poseJobPromises).then(function () { consensusPose(); releasePose(); }, function () { releasePose(); });
            }
        };

        // Bir fotoğrafın yönü: bağımsız tek görüntülük okumalar. Ucuz modelle iki bağımsız okuma; uyuşmazsa Opus hakem (ön görünümde de: baş aşağı ön kare
        // tek okumada 0° çıkabiliyordu). En az iki okuma uyuşmuyorsa null (yön yüklemeden sonra eski yolla düzeltilir).
        async function poseFor(i) {
            const read = function (model, effort) {
                return sendHedged({ type: 'ids-pose', model: model, effort: effort, images: [{ index: i + 1, data: infos[i].data }] })
                    .then(function (reply) { return (reply.items || [])[0] || null; })
                    .catch(function () { return null; });
            };
            const r1 = await read(SETTINGS.poseModel, SETTINGS.poseEffort);
            if (r1 && r1.view === 'other') return null;
            const r2 = poseValid(r1) ? await read(SETTINGS.poseModel, SETTINGS.poseEffort) : null;
            if (poseValid(r1) && poseValid(r2) && poseAgree(r1, r2)) return r1;
            const r3 = await read('opus', SETTINGS.poseArbiterEffort);
            return poseVote([r1, r2, r3]);
        }

        async function cropIndex(i, items, pose) {
            const file = batch[i];
            const item = items.find(function (it) { return Number(it.index) === i + 1; });
            if (!item || item.slot === 'other' || !(Number(item.confidence) >= SETTINGS.minConfidence)) {
                if (item && item.note) noteBy[i].push(file.name + ': ' + item.note);
                return;
            }
            const face = FACE.test(item.slot);
            const frame = INTRAORAL.test(item.slot) ? intraoralFrameAny(item, infos[i].w, infos[i].h) : null;
            const occ = /^occlussal_/.test(item.slot) ? occlusalBox(item) : null;
            let box = finalBox(frame ? frame.box : (occ || [item.x0, item.y0, item.x1, item.y1]),
                face ? SETTINGS.faceMargin : (occ ? SETTINGS.occlusalMargin : SETTINGS.margin), face ? SETTINGS.faceRatio : 0, infos[i].w, infos[i].h);
            if (!box) return;
            if (!face) box = relaxBox(box, infos[i].w, infos[i].h, frame ? SETTINGS.maxAspect : 0, SETTINGS.minOutW, SETTINGS.minOutH);
            if (/^occlussal_/.test(item.slot)) {
                if (!occ) noteBy[i].push(file.name + ': oklüzal diş sınırı ölçülemedi, modelin kutusu kullanıldı');
                else if ((box[2] - box[0]) * (box[3] - box[1]) > 0.9) noteBy[i].push(file.name + ': oklüzal kutu neredeyse tüm kareyi kaplıyor, kırpma etkisiz');
            }
            const tilt = frame ? frame.tilt : 0;
            // Yön: bağımsız oylanmış okuma varsa kare burada döndürülür (oklüzalde aynalanır); sağ/sol bukkal gerçek yanla düzeltilir.
            // Çene (üst/alt): kırpma etiketi, odaklı çene ölçümü (ids-arch) ve yön okumalarının oy çokluğu; tek bir çağrıya güvenilmez
            // (kırpma etiketi üç alt oklüzali "üst", çene ölçümü bir alt oklüzali "üst" demişti). Beraberlikte kırpma etiketi kalır.
            let poseUse = pose;
            if (/^occlussal_/.test(item.slot)) {
                const votes = [item.slot === 'occlussal_upper' ? 'upper' : 'lower', item.arch, pose && pose.view === 'occlusal' ? pose.arch : null]
                    .filter(function (v) { return v === 'upper' || v === 'lower'; });
                const up = votes.filter(function (v) { return v === 'upper'; }).length;
                const arch = up * 2 > votes.length ? 'upper' : up * 2 < votes.length ? 'lower' : (item.slot === 'occlussal_upper' ? 'upper' : 'lower');
                const slotName = arch === 'upper' ? 'occlussal_upper' : 'occlussal_lower';
                if (slotName !== item.slot) {
                    noteBy[i].push(file.name + ': ' + (arch === 'upper' ? 'üst' : 'alt') + ' oklüzal olarak düzeltildi (çene oylamasıyla)');
                    item.slot = slotName;
                }
                item.arch = arch;
                if (pose && pose.view === 'occlusal') poseUse = Object.assign({}, pose, { arch: arch });
            }
            let orient = null;
            if (poseUse && SETTINGS.rotateAtCrop) {
                const t = orientTarget(item.slot, poseUse);
                if (!t) {
                    noteBy[i].push(file.name + ': yön okuması kararsız kaldı, yön yüklemeden sonra düzeltilecek');
                } else if (/^buccal_/.test(item.slot) && t.slot !== item.slot) {
                    noteBy[i].push(file.name + ': sağ/sol yön okumasıyla düzeltildi (' + (t.slot === 'buccal_right' ? 'sağ' : 'sol') + ' bukkal)');
                    item.slot = t.slot;
                    orient = t;
                } else {
                    orient = t;
                }
            }
            try {
                const result = await cropOne(file, box, tilt, frame ? frame.pivot : null, orient);
                if (tilt) noteBy[i].push(file.name + ': oklüzal düzlem ' + Math.abs(tilt).toFixed(1) + '° düzeltildi');
                if (frame && !frame.rotated && !frame.upper && !frame.lower) noteBy[i].push(file.name + ': ekartör kolu ölçülemedi, modelin kutusu kullanıldı');
                out[i] = result.file;
                cropBy[i] = { name: file.name, slot: item.slot, file: result.file, width: result.width, height: result.height,
                    sig: result.sig, thumb: infos[i].data, bright: infos[i].bright, sharp: infos[i].sharp,
                    score: qualityScore(infos[i]), arch: item.arch || null,
                    pose: orient ? { applied: true, rotate: orient.rotate, mirror: orient.mirror } : null };
                if (orient && (orient.rotate || orient.mirror)) noteBy[i].push(file.name + ': yön kırpma sırasında düzeltildi (' + orient.rotate + '°' + (orient.mirror ? ', ayna' : '') + ')');
                if (item.note) noteBy[i].push(file.name + ': ' + item.note);
            } catch (error) {
                noteBy[i].push(file.name + ': kırpılamadı (' + error.message + ')');
            }
        }

        const tick = function () {
            say('Yapay zeka kırpma kutularını hesaplıyor… ' + secs(preparedAt) + ' sn (' + answered + '/' + groups.length +
                ' bölüm yanıtladı, ' + finished + '/' + batch.length + ' fotoğraf işlendi)');
        };
        tick();
        const timer = setInterval(tick, 1000);
        try {
            await Promise.all(groups.map(async function (idx) {
                let items;
                try {
                    const reply = await sendHedged({
                        type: 'ids-crop',
                        effort: SETTINGS.cropEffort,
                        images: idx.map(function (i) { return { index: i + 1, data: infos[i].data }; })
                    });
                    items = reply.items || [];
                } catch (error) {
                    errors.push(error.message);
                    idx.forEach(function (i) {
                        noteBy[i].push(batch[i].name + ': kırpma kutusu alınamadı (' + error.message + '), olduğu gibi yüklenecek');
                        finished++;
                    });
                    groupDone();
                    return;
                }
                answered++;
                const bySlot = function (i) { return items.find(function (it) { return Number(it.index) === i + 1; }); };
                // Yön: ağız içi etiketli her kare için bağımsız okuma hemen başlar (oklüzal ölçümüyle paralel). Sağ/sol bukkal artık buradan
                // (üst çene + ön diş yönü) hesaplanır; kırpma modelinin sağ/sol tahmini yan çevrilmiş karelerde güvenilmezdi.
                idx.forEach(function (i) {
                    const it = bySlot(i);
                    if (!SETTINGS.rotateAtCrop || !it || !(Number(it.confidence) >= SETTINGS.minConfidence)) return;
                    if (!/^(labial_|buccal_|occlussal_)/.test(it.slot)) return;
                    poseStarted[i] = true;
                    poseJobPromises.push(posePool(function () { return poseFor(i); }).catch(function () { return null; }).then(function (r) { poseResults[i] = r; }));
                });
                groupDone();
                // Oklüzal kareler: diş sırası kutusu ayrı ve güçlü bir okumayla alınır (kırpma modelinin geniş istemindeki
                // ölçüm uzaktan çekilmiş karelerde güvenilmezdi); geçersiz/aşırı geniş kutu atılır.
                const occl = idx.filter(function (i) {
                    const it = bySlot(i);
                    return it && /^occlussal_/.test(it.slot) && Number(it.confidence) >= SETTINGS.minConfidence;
                });
                const archWork = (async function () {
                    if (!occl.length) return;
                    try {
                        const reply = await sendHedged({
                            type: 'ids-arch',
                            effort: SETTINGS.archEffort,
                            model: SETTINGS.archModel,
                            images: occl.map(function (i) { return { index: i + 1, data: infos[i].data }; })
                        });
                        const notOccl = [];
                        (reply.items || []).forEach(function (r) {
                            const i = Number(r.index) - 1;
                            const it = bySlot(i);
                            if (!it || occl.indexOf(i) < 0) return;
                            const l = num(r.teeth_left), rt = num(r.teeth_right), t = num(r.teeth_top), b = num(r.teeth_bottom);
                            // Diş kutusunun piksel en-boy oranı: oklüzal diş sırası yaklaşık kare/yatay (kamera 90° dönükse dikey) bir
                            // kutudur; çok ince şerit oklüzal olmayan (dik tutulmuş ön/yan) kareye ait demektir.
                            const aspect = b > t ? ((rt - l) * infos[i].w) / ((b - t) * infos[i].h) : 0;
                            if (r.is_occlusal === false || (rt - l > 0.05 && b - t > 0.05 && (aspect < SETTINGS.archAspectMin || aspect > SETTINGS.archAspectMax))) {
                                notOccl.push(i);
                                return;
                            }
                            const sane = rt - l > 0.1 && b - t > 0.1 && l >= 0 && t >= 0 && rt <= 1 && b <= 1 && (rt - l) * (b - t) < 0.92;
                            it.arch = r.arch;
                            it.arch_incisors_side = r.incisors_side;
                            if (sane) {
                                it.teeth_left = l; it.teeth_right = rt; it.teeth_top = t; it.teeth_bottom = b;
                                it.arch_checked = true;
                            } else {
                                noteBy[i].push(batch[i].name + ': oklüzal diş sırası kutusu güvenilir ölçülemedi, ilk ölçüm kullanıldı');
                            }
                        });
                        // Oklüzal olmadığı anlaşılan kareler (ör. dik tutulmuş ön kare): kırpma modeline "oklüzal değil" ipucuyla
                        // yeniden sorulur; yine oklüzal derse ya da yanıt gelmezse kırpılmadan yüklenir (ince şerit olmasın).
                        if (notOccl.length) {
                            let again = [];
                            try {
                                const second = await sendHedged({
                                    type: 'ids-crop', effort: SETTINGS.cropEffort, hint: 'not-occlusal',
                                    images: notOccl.map(function (i) { return { index: i + 1, data: infos[i].data }; })
                                });
                                again = second.items || [];
                            } catch (error) { /* aşağıda kırpılmaz */ }
                            notOccl.forEach(function (i) {
                                const fresh = again.filter(function (x) { return Number(x.index) === i + 1; })[0];
                                const pos = items.findIndex(function (x) { return Number(x.index) === i + 1; });
                                if (fresh && !/^occlussal_/.test(fresh.slot) && pos >= 0) {
                                    if (fresh.slot !== 'other') fresh.confidence = Math.max(Number(fresh.confidence) || 0, SETTINGS.minConfidence);
                                    items[pos] = fresh;
                                    noteBy[i].push(batch[i].name + ': oklüzal değil, ' + fresh.slot + ' olarak yeniden değerlendirildi');
                                } else if (pos >= 0) {
                                    items[pos].slot = 'other';
                                    noteBy[i].push(batch[i].name + ': oklüzal görünmüyor, kırpılmadan yüklenecek');
                                }
                            });
                        }
                    } catch (error) {
                        occl.forEach(function (i) {
                            noteBy[i].push(batch[i].name + ': oklüzal diş sırası okuması alınamadı (' + error.message + '), ilk ölçüm kullanıldı');
                        });
                    }
                })();
                await Promise.all(idx.map(async function (i) {
                    if (occl.indexOf(i) >= 0) await archWork;
                    if (poseStarted[i]) await poseBarrier;
                    const pose = poseResults[i] || null;
                    return cropLimit(async function () {
                        try { await cropIndex(i, items, pose); } finally { finished++; }
                    });
                }));
            }));
        } finally {
            clearInterval(timer);
        }
        if (errors.length === groups.length) throw new Error(errors[0]);

        const cropItems = cropBy.filter(Boolean);
        return {
            files: out, cropped: cropItems.length, total: batch.length,
            notes: [].concat.apply([], noteBy).concat(files.length > batch.length ? [(files.length - batch.length) + ' fotoğraf sınırın (' + SETTINGS.maxImages + ') dışında kaldı, kırpılmadan yüklenecek'] : []), items: cropItems,
            timing: { prepare: Math.round((preparedAt - started) / 1000), total: secs(started), groups: groups.length }
        };
    }

    window.idsfyCrop = { orientTarget: orientTarget, poseValid: poseValid, poseAgree: poseAgree, poseVote: poseVote, relaxBox: relaxBox, cropFiles: cropFiles, finalBox: finalBox, intraoralFrame: intraoralFrame, intraoralFrameAny: intraoralFrameAny, occlusalBox: occlusalBox, matchOriginal: matchOriginal,
        matchGroup: matchGroup, buccalSide: buccalSide, qualityScore: qualityScore, SETTINGS: SETTINGS };
})();
