// IDS Foto Yükleyici - sayfa betiği.
// IDS'in Fotoğraflar adımında bir panel açar. Hasta klasörü seçilince dosyalar IDS'in
// kendi otomatik sıralamasına bırakılır; ardından ağız içi beş yuvanın yönü yapay
// zekayla okunur ve IDS'in kalem menüsündeki döndürme/çevirme araçlarıyla düzeltilir.
(function () {
    'use strict';

    // Düzeltilen yuvalar (anahtarların yazımı IDS'in).
    const SLOTS = [
        { key: 'occlussal_upper', label: 'Üst oklüzal' },
        { key: 'occlussal_lower', label: 'Alt oklüzal' },
        { key: 'buccal_right', label: 'Sağ bukkal' },
        { key: 'labial_anterior', label: 'Ağız içi önden' },
        { key: 'buccal_left', label: 'Sol bukkal' }
    ];

    // Yönler saat yönünde derecedir: üst 0, sağ 90, alt 180, sol 270.
    const SIDE = { top: 0, right: 90, bottom: 180, left: 270 };

    // Kalem menüsündeki düğmelerin sırası (metinler dile göre değiştiği için sıra kullanılır).
    const MENU = { flipVertical: 0, flipHorizontal: 1, rotateLeft: 2, rotateRight: 3 };

    // crop: bu yüklemede kendiliğinden kırpma yapıldıysa {originals, cropped, total, notes};
    // cropping: kırpma sürüyor; skipCrop: bir sonraki yükleme kırpılmadan yapılır.
    const state = { busy: false, results: {}, stopped: false, crop: null, cropping: false, skipCrop: false };
    let panel = null;

    // Ayar sayfasındaki "yüklemeden önce kırp" seçeneği (varsayılan açık).
    function cropEnabled() {
        return new Promise(function (resolve) {
            if (!chrome.storage || !chrome.storage.local) return resolve(true);
            chrome.storage.local.get('idsfyCropPhotos', function (stored) {
                resolve(!stored || stored.idsfyCropPhotos !== false);
            });
        });
    }

    // "Durdur": bu hastada klasör kendiliğinden bırakılmaz, yönler düzeltilmez, "İleri"ye basılmaz.
    // Hasta (sihirbaz) ya da form (reçete) başına oturum boyunca hatırlanır.
    function stopKey() {
        const params = new URLSearchParams(location.search);
        return 'idsfy-photos-stop-' + (params.get('patientId') || params.get('formId') || '');
    }

    // Reçetede form doldurucu (rx.js) "Durdur" ile durdurulmuşsa fotoğraflar da kendiliğinden
    // bırakılmaz.
    function rxStopped() {
        return new Promise(function (resolve) {
            if (!/\/rx\//.test(location.pathname) || !chrome.storage || !chrome.storage.local) return resolve(false);
            const formId = new URLSearchParams(location.search).get('formId');
            chrome.storage.local.get('idsRxFill', function (stored) {
                const st = stored && stored.idsRxFill;
                resolve(!!(st && st.formId === formId && st.auto === false));
            });
        });
    }

    function sleep(ms) {
        return new Promise(function (resolve) { setTimeout(resolve, ms); });
    }

    async function waitFor(check, timeoutMs) {
        const until = Date.now() + timeoutMs;
        while (Date.now() < until) {
            const value = check();
            if (value) return value;
            await sleep(150);
        }
        return null;
    }

    function turn(degrees) {
        return ((degrees % 360) + 360) % 360;
    }

    // ---------- IDS sayfası ----------

    function onPhotosStep() {
        return !!document.querySelector(
            'input[type="file"][id$="-uploader-input"], input[type="file"][id$="-uploaded-photo-input"]'
        );
    }

    function tileOf(slot) {
        const filled = document.querySelector('input[type="file"][id$="-' + slot + '-uploaded-photo-input"]');
        return filled ? filled.parentElement : null;
    }

    function previewOf(slot) {
        const tile = tileOf(slot);
        return tile ? tile.querySelector('img[class*="Preview-photo"]:not([class*="Blur"])') : null;
    }

    function matrixOf(element) {
        const text = getComputedStyle(element).transform;
        if (!text || text === 'none') return [1, 0, 0, 1];
        return text.slice(text.indexOf('(') + 1).split(',').slice(0, 4).map(Number);
    }

    // IDS döndürmeyi resmin kendisine, çevirmeleri (ekran eksenlerinde) sarmalayıcıya uygular.
    function readOrientation(slot) {
        const img = previewOf(slot);
        if (!img) return null;
        const m = matrixOf(img);
        const quarter = Math.round(Math.atan2(m[1], m[0]) / (Math.PI / 2));
        const wrap = matrixOf(img.closest('[class*="Preview-photoWrapper"]') || img.parentElement);
        return { rotate: turn(quarter * 90), flipX: wrap[0] < 0, flipY: wrap[3] < 0 };
    }

    function menuButtons() {
        const menu = document.querySelector('[class*="Dropdown-dropdownMenu"]:not([class*="Item"])');
        return menu ? menu.querySelectorAll('button') : null;
    }

    function closeMenus() {
        ['pointerdown', 'mousedown', 'mouseup', 'click'].forEach(function (type) {
            document.body.dispatchEvent(new MouseEvent(type, { bubbles: true }));
        });
    }

    async function clickTool(slot, index) {
        const buttons = menuButtons();
        if (!buttons || !buttons[index]) throw new Error('düzenleme menüsü bulunamadı');
        const before = JSON.stringify(readOrientation(slot));
        buttons[index].click();
        const changed = await waitFor(function () {
            return JSON.stringify(readOrientation(slot)) !== before;
        }, 4000);
        if (!changed) throw new Error('IDS düzenleme aracı yanıt vermedi');
    }

    // Hedef: ham kare önce saat yönünde target.rotate kadar döndürülmüş, sonra
    // target.mirror ise sağ-sol aynalanmış görünsün.
    async function applyOrientation(slot, target) {
        const tile = tileOf(slot);
        const pencil = tile && tile.querySelector('[class*="UploadedPhoto-editButton"]');
        if (!pencil) throw new Error('düzenle düğmesi bulunamadı');
        closeMenus();
        await sleep(200);
        pencil.click();
        if (!(await waitFor(menuButtons, 4000))) throw new Error('düzenleme menüsü açılmadı');
        try {
            let now = readOrientation(slot);
            const steps = turn(target.rotate - now.rotate) / 90;
            if (steps === 3) {
                await clickTool(slot, MENU.rotateLeft);
            } else {
                for (let i = 0; i < steps; i++) await clickTool(slot, MENU.rotateRight);
            }
            now = readOrientation(slot);
            if (now.flipX !== target.mirror) await clickTool(slot, MENU.flipHorizontal);
            now = readOrientation(slot);
            if (now.flipY) await clickTool(slot, MENU.flipVertical);
        } finally {
            closeMenus();
        }
        const end = readOrientation(slot);
        if (end.rotate !== target.rotate || end.flipX !== target.mirror || end.flipY) {
            throw new Error('IDS beklenen yöne getirilemedi');
        }
    }

    // ---------- Yön kararı ----------

    // Kliniğin kuralları:
    //  - Oklüzaller aynayla çekilir: kesiciler üst arkta yukarı ("n"), alt arkta aşağı
    //    ("u") gelecek şekilde döndürülür ve her zaman ayna görüntüsü alınır.
    //  - Ağız içi önden: üst çene yukarı gelecek şekilde döndürülür.
    //  - Bukkaller: üst çene yukarı gelecek şekilde döndürülür; bu durumda sağ bukkalde ön
    //    dişler sağda, sol bukkalde solda olmalıdır. Değilse kare karşı yuvaya aittir
    //    (fixBuccalSides yuvaları değiştirir; yapamazsa uyarı verilir).
    function decide(slot, item) {
        const upper = SIDE[item.upper_jaw_side];
        const incisors = SIDE[item.incisors_side];
        const target = { rotate: 0, mirror: false, warning: item.note || '' };
        const warn = function (text) { target.warning = target.warning ? target.warning + '; ' + text : text; };
        if (slot === 'occlussal_upper' || slot === 'occlussal_lower') {
            if (incisors === undefined) return null;
            target.rotate = turn((slot === 'occlussal_upper' ? 0 : 180) - incisors);
            target.mirror = true;
        } else if (slot === 'labial_anterior') {
            if (upper === undefined) return null;
            target.rotate = turn(-upper);
        } else {
            // Üst çene her zaman yukarıda (kliniğin kuralı); yuvanın yanı ön dişlerin yönünden doğrulanır.
            // Eskiden döndürme ön dişleri yuvanın yanına çevirecek şekilde seçiliyordu; kare yanlış yuvadaysa
            // baş aşağı kalıyordu.
            const wanted = slot === 'buccal_right' ? 90 : 270;
            if (upper !== undefined) {
                target.rotate = turn(-upper);
                if (incisors === undefined) {
                    warn('ön dişlerin yönü okunamadı, sağ/sol kontrol edin');
                } else if (turn(incisors + target.rotate) !== wanted) {
                    warn('sağ/sol şüpheli, bu fotoğraf karşı yuvaya ait olabilir');
                }
            } else if (incisors !== undefined) {
                target.rotate = turn(wanted - incisors);
                warn('üst çenenin yönü okunamadı, kontrol edin');
            } else {
                return null;
            }
        }
        return target;
    }

    function blobToBase64(blob) {
        return new Promise(function (resolve, reject) {
            const reader = new FileReader();
            reader.onload = function () { resolve(String(reader.result).split(',')[1]); };
            reader.onerror = function () { reject(reader.error); };
            reader.readAsDataURL(blob);
        });
    }

    // Modele IDS önizlemesinin ham hali gider (IDS'te uygulanmış döndürmeler hariç).
    async function previewImage(slot) {
        const img = previewOf(slot);
        if (!img) return null;
        const blob = await (await fetch(img.src, { credentials: 'include' })).blob();
        // Yüklemeden önce kırpıldıysa yön kırpılmamış kareden okunur: sıkı kırpılmış karede burun,
        // çene ve ekartör gibi ipuçları kalmadığından model üst-alt çeneyi karıştırabiliyor.
        if (state.crop && state.crop.items && state.crop.items.length && window.idsfyCrop) {
            try {
                const group = await window.idsfyCrop.matchGroup(blob, state.crop.items);
                const match = group.length ? bestOf(group) : null;
                if (match) return { slot: slot, media_type: 'image/jpeg', data: match.thumb, original: match.name };
            } catch (error) { /* önizlemeyle sürer */ }
        }
        const type = ['image/jpeg', 'image/png', 'image/webp'].indexOf(blob.type) >= 0 ? blob.type : 'image/jpeg';
        return { slot: slot, media_type: type, data: await blobToBase64(blob) };
    }

    function askOrientation(images) {
        return new Promise(function (resolve, reject) {
            // Eklenti yenilenince açık sayfadaki eski betik arka planla konuşamaz.
            if (!chrome.runtime || !chrome.runtime.id) {
                return reject(new Error('Eklenti güncellendi; bu sayfayı yenileyin (F5).'));
            }
            chrome.runtime.sendMessage({ type: 'ids-orient', images: images }, function (reply) {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!reply || !reply.ok) return reject(new Error(reply ? reply.error : 'yanıt yok'));
                resolve(reply.items);
            });
        });
    }

    function describe(target) {
        const parts = [];
        if (target.rotate) parts.push(target.rotate + '° döndürüldü');
        if (target.mirror) parts.push('ayna görüntüsü alındı');
        return parts.length ? parts.join(', ') : 'yön doğru, dokunulmadı';
    }

    // ---------- Panel ----------

    function el(tag, className, text) {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text) node.textContent = text;
        return node;
    }

    function setStatus(text, isError) {
        const status = panel.querySelector('.idsfy-status');
        status.textContent = text;
        status.classList.toggle('idsfy-error', !!isError);
    }

    // IDS bir yuvaya "Görüntü çözünürlüğü, fotoğraf gerekliliklerini karşılamıyor" ünlemini koyduysa o yuvaların anahtarları
    // (karo içindeki Placeholder-<yuva> sınıfından). Ünlem karosu yalnız uyarı varken DOM'da bulunur.
    function idsResolutionWarnings() {
        const keys = [];
        document.querySelectorAll('[class*="Tile-warningIconWrap"]').forEach(function (icon) {
            const tile = icon.closest('[class*="Tile-photoTile"]');
            const holder = tile && tile.querySelector('[class*="Placeholder-placeholder"]');
            const m = holder && String(holder.className).match(/Placeholder-(profile_repose|frontal_repose|frontal_smiling|occlussal_upper|occlussal_lower|buccal_right|buccal_left|labial_anterior)\b/);
            if (m && keys.indexOf(m[1]) < 0) keys.push(m[1]);
        });
        return keys;
    }

    // Elle düzeltme düğmeleri: uyarılı ya da hatalı satırda ekranda görünen fotoğraf saat yönünde 90/180/270° döndürülür
    // (IDS'in döndürme düğmeleriyle); "sağ/sol şüpheli" uyarısında kare karşı bukkal yuvaya taşınır.
    function fixButtons(slotKey, result) {
        const bar = el('div', 'idsfy-fixbar');
        [90, 180, 270].forEach(function (deg) {
            const button = el('button', 'idsfy-mini', '↻ ' + deg + '°');
            button.type = 'button';
            button.title = 'Fotoğrafı ekranda göründüğü haliyle saat yönünde ' + deg + '° döndür';
            button.disabled = state.busy;
            button.addEventListener('click', function () { rotateBy(slotKey, deg); });
            bar.appendChild(button);
        });
        if (/^buccal_/.test(slotKey) && /sağ\/sol şüpheli/.test(result.warning || '')) {
            const move = el('button', 'idsfy-mini', 'Karşı yuvaya taşı');
            move.type = 'button';
            move.title = 'Bu fotoğrafı karşı bukkal yuvaya taşır (karşı yuva doluysa yer değiştirir), sonra yönleri yeniden düzeltir';
            move.disabled = state.busy;
            move.addEventListener('click', function () { moveToOpposite(slotKey); });
            bar.appendChild(move);
        }
        return bar;
    }

    // Ekranda görünen yöne göre döndürür. Ayna açıkken (oklüzaller) IDS'in döndürmesi aynalamadan önce uygulandığından
    // ekranda ters görünür: görünen saat yönü için dönüş eksi alınır.
    async function rotateBy(slotKey, degrees) {
        if (state.busy) return;
        state.busy = true;
        render();
        const label = SLOTS.find(function (s) { return s.key === slotKey; }).label;
        setStatus(label + ' ' + degrees + '° döndürülüyor…');
        try {
            const now = readOrientation(slotKey);
            if (!now) throw new Error('önizleme bulunamadı');
            await applyOrientation(slotKey, { rotate: turn(now.rotate + (now.flipX ? -degrees : degrees)), mirror: now.flipX });
            state.results[slotKey] = { ok: true, text: 'elle ' + degrees + '° döndürüldü', manual: true };
            setStatus(label + ' ' + degrees + '° döndürüldü.');
        } catch (error) {
            state.results[slotKey] = { ok: false, text: error.message };
            setStatus(label + ' döndürülemedi: ' + error.message, true);
        }
        state.busy = false;
        render();
    }

    // Bukkal fotoğrafı karşı yuvaya taşır: karşı yuva boşsa yükleyip kaynağı siler, doluysa yer değiştirir (kırpılmış dosyalar
    // kullanılır; eşlenemezse elle taşınmalıdır, IDS önizlemesinin düşük çözünürlüklü kopyası yüklenmez). Sonra yönler yeniden düzeltilir.
    async function moveToOpposite(slotKey) {
        if (state.busy) return;
        const other = slotKey === 'buccal_right' ? 'buccal_left' : 'buccal_right';
        state.busy = true;
        render();
        const label = function (key) { return SLOTS.find(function (s) { return s.key === key; }).label; };
        let moved = false;
        try {
            const mine = await cropItemOfSlot(slotKey);
            if (!mine) throw new Error('dosya eşlenemedi (kırpma kaydı yok); elle taşıyın');
            if (!tileOf(other)) {
                setStatus(label(slotKey) + ' fotoğrafı ' + label(other) + ' yuvasına taşınıyor…');
                await uploadToEmptySlot(other, mine.file);
                await deleteSlot(tileOf(slotKey), slotKey);
            } else {
                const theirs = await cropItemOfSlot(other);
                if (!theirs || theirs === mine) throw new Error('karşı yuvadaki dosya eşlenemedi; elle değiştirin');
                setStatus(label(slotKey) + ' ve ' + label(other) + ' yer değiştiriyor…');
                await replaceInSlot(slotKey, theirs.file);
                await replaceInSlot(other, mine.file);
            }
            moved = true;
            if (state.crop) {
                mine.slot = other;
                state.crop.notes.push(mine.name + ': elle ' + label(other) + ' yuvasına taşındı');
            }
        } catch (error) {
            state.results[slotKey] = { ok: false, text: error.message };
            setStatus(label(slotKey) + ' taşınamadı: ' + error.message, true);
        }
        state.busy = false;
        render();
        if (moved) await onFix(false);
    }

    function render() {
        const list = panel.querySelector('.idsfy-list');
        list.textContent = '';
        SLOTS.forEach(function (slot) {
            const result = state.results[slot.key];
            if (!result) return;
            const row = el('div', 'idsfy-row' + (result.ok ? '' : ' idsfy-row-error'));
            row.appendChild(el('span', 'idsfy-label', slot.label));
            row.appendChild(el('span', 'idsfy-info', result.text));
            if (result.warning) row.appendChild(el('span', 'idsfy-warning', '⚠ ' + result.warning));
            if ((result.warning || !result.ok || result.manual) && previewOf(slot.key)) row.appendChild(fixButtons(slot.key, result));
            list.appendChild(row);
        });
        panel.querySelectorAll('.idsfy-button:not(.idsfy-stop)').forEach(function (button) {
            button.disabled = state.busy;
        });
        const stopButton = panel.querySelector('.idsfy-stop');
        if (stopButton) stopButton.textContent = state.stopped ? 'Devam et' : 'Durdur';
    }

    // Yüklemenin bittiği, IDS'in görüntü servisine attığı isteklerden anlaşılır: page.js
    // bırakmadan sonra başlayan ve süren istek sayılarını <html> özniteliklerine yazar.
    // İstekler başlamış, hiçbiri sürmüyor ve kısa bir süredir yenisi gelmiyorsa tüm
    // fotoğraflar yüklenmiş demektir; yönler o zaman düzeltilir.
    const QUIET_MS = 2500;
    const START_TIMEOUT_MS = 3 * 60000;
    const UPLOAD_TIMEOUT_MS = 20 * 60000;

    function uploadCounts() {
        const data = document.documentElement.dataset;
        return { started: Number(data.idsfyStarted || 0), pending: Number(data.idsfyPending || 0),
            failed: Number(data.idsfyFailed || 0) };
    }

    function previewsLoaded() {
        return SLOTS.every(function (slot) {
            const img = previewOf(slot.key);
            return !img || (img.complete && img.naturalWidth > 0);
        });
    }

    async function fixWhenUploaded(fileCount, explicit) {
        const began = Date.now();
        let quietSince = 0;
        let lastStarted = 0;
        let reconciled = false;
        while (Date.now() - began < UPLOAD_TIMEOUT_MS) {
            await sleep(500);
            if (state.busy || (state.stopped && !explicit)) return;
            const now = uploadCounts();
            if (!now.started) {
                // IDS önce tüm kareleri sınıflandırır; yükleme istekleri ondan sonra başlar.
                if (Date.now() - began > START_TIMEOUT_MS) {
                    setStatus('IDS hiçbir fotoğrafı yuvalara yerleştirmedi (yuvalar doluysa yerleştirmez). ' +
                        'Gerekirse "2. Yönleri düzelt"e basın.', true);
                    return;
                }
                setStatus(fileCount
                    ? fileCount + ' fotoğraf IDS\'e bırakıldı; IDS sınıflandırıyor…'
                    : 'Fotoğraf yüklemesi bekleniyor (klasörden ya da elle)…');
                continue;
            }
            if (now.pending > 0 || now.started !== lastStarted || !previewsLoaded()) {
                lastStarted = now.started;
                quietSince = 0;
                setStatus('IDS fotoğrafları yüklüyor…');
                continue;
            }
            if (!quietSince) quietSince = Date.now();
            if (Date.now() - quietSince >= QUIET_MS) {
                // Yükleme durulunca bir kez: yuvalar modelin yuvalarıyla uzlaştırılır; değişiklik olduysa
                // yeni yüklemelerin bitmesi yeniden beklenir.
                if (!reconciled) {
                    reconciled = true;
                    if (await reconcileSlots()) { quietSince = 0; lastStarted = 0; continue; }
                }
                if (now.failed) setStatus('Bazı yükleme istekleri başarısız oldu; yuvaları kontrol edin.', true);
                askCrop(await onFix(!explicit));
                return;
            }
        }
        setStatus('Yükleme çok uzun sürdü; bitince "2. Yönleri düzelt"e basın.', true);
    }

    // explicit: kullanıcı düğmeye bastı; "Durdur" açık olsa da yüklenir ve yönler düzeltilir
    // (yalnızca "İleri"ye basılmaz).
    async function onFolder(fileList, bridge, explicit) {
        let files = Array.from(fileList).filter(function (f) {
            return /\.(jpe?g|png)$/i.test(f.name);
        });
        if (!files.length) {
            setStatus('Klasörde JPG/PNG bulunamadı.', true);
            return;
        }
        if (state.cropping) {
            setStatus('Fotoğraflar hâlâ kırpılıyor; bekleyin.');
            return;
        }
        // Yüklemeden önce kendiliğinden kırpma (crop.js). Başarısız olursa orijinaller yüklenir.
        state.crop = null;
        const originals = files;
        if (!state.skipCrop && window.idsfyCrop && await cropEnabled()) {
            state.cropping = true;
            try {
                const result = await window.idsfyCrop.cropFiles(files, setStatus);
                files = result.files;
                state.crop = { originals: originals, cropped: result.cropped, total: result.total, notes: result.notes,
                    items: result.items || [], timing: result.timing || null };
            } catch (error) {
                setStatus('Kırpma yapılamadı (' + error.message + '); fotoğraflar olduğu gibi yükleniyor.', true);
                await sleep(1500);
            } finally {
                state.cropping = false;
            }
        }
        state.skipCrop = false;
        const transfer = new DataTransfer();
        files.forEach(function (f) { transfer.items.add(f); });
        bridge.files = transfer.files;
        delete bridge.dataset.result;
        document.dispatchEvent(new CustomEvent('idsfy-drop'));
        const result = bridge.dataset.result || 'error:sayfa köprüsü yanıt vermedi (sayfayı yenileyin)';
        if (result.indexOf('ok:') === 0) {
            setStatus(files.length + ' fotoğraf IDS\'e bırakıldı; IDS sınıflandırıyor…');
            fixWhenUploaded(files.length, explicit);
        } else {
            setStatus('Hata: ' + result.slice(6), true);
        }
    }

    // ---------- Yuva düzeltmeleri ----------

    // Ham karede üst çeneyi yukarı alan döndürmeden sonra ön dişler sağdaysa sağ bukkal, soldaysa sol bukkaldir
    // (kliniğin kuralı; fotoğraflar aynasız çekilir). Sağ/sol bu yüzden yön okumasından kesin bilinir: kırpma
    // modelinin yan çevrilmiş karelerdeki sağ/sol tahmini güvenilmezdi (29 Ekim 2026). Belirsizse null.
    function buccalSideOf(item) {
        const upper = SIDE[item.upper_jaw_side];
        const incisors = SIDE[item.incisors_side];
        if (upper === undefined || incisors === undefined) return null;
        const after = turn(incisors - upper);
        return after === 90 ? 'buccal_right' : after === 270 ? 'buccal_left' : null;
    }

    // Yuvadaki önizlemeyi imzayla kırpılmış dosyaya eşler ({name, slot, file, ...}); eşlenemezse null.
    async function cropItemOfSlot(key) {
        const crop = state.crop;
        if (!crop || !crop.items || !window.idsfyCrop) return null;
        const img = previewOf(key);
        if (!img) return null;
        const blob = await (await fetch(img.src, { credentials: 'include' })).blob();
        // Benzer çekimler (ikizler) imzayla ayırt edilemez: aynı görünümün 2-3 çekimi olan klasörlerde eşleşme tek kare vermiyordu ve
        // sağ/sol yer değiştirme "dosyalar eşlenemedi" diye yapılamıyordu (30 Ekim 2026, Bera Arat). Gruptan en iyi kare alınır.
        const group = await window.idsfyCrop.matchGroup(blob, crop.items.filter(function (it) { return it.file; }));
        return group.length ? bestOf(group) : null;
    }

    function previewReady(key) {
        const img = previewOf(key);
        return !!(img && img.complete && img.naturalWidth > 0);
    }

    // Boş yuvanın dosya girişine doğrudan yükler (IDS sınıflandırmayı atlar); önizleme gelene kadar bekler.
    async function uploadToEmptySlot(key, file) {
        const input = document.querySelector('input[type="file"][id$="-' + key + '-uploader-input"]');
        if (!input) throw new Error('boş yuva girişi bulunamadı');
        const transfer = new DataTransfer();
        transfer.items.add(file);
        input.files = transfer.files;
        input.dispatchEvent(new Event('change', { bubbles: true }));
        if (!(await waitFor(function () { return previewReady(key); }, 60000))) throw new Error('yükleme tamamlanmadı');
        await sleep(600);
    }

    // Dolu yuvadaki fotoğrafı kalem menüsündeki "Değiştir" girişiyle yenisiyle değiştirir (silmeden).
    async function replaceInSlot(key, file) {
        const tile = tileOf(key);
        const pencil = tile && tile.querySelector('[class*="UploadedPhoto-editButton"]');
        if (!pencil) throw new Error('düzenle düğmesi bulunamadı');
        const before = previewOf(key);
        const beforeSrc = before ? before.src : '';
        closeMenus();
        await sleep(200);
        pencil.click();
        const input = await waitFor(function () {
            return document.querySelector('input[type="file"][id$="-' + key + '-dropdown-input"]');
        }, 4000);
        if (!input) { closeMenus(); throw new Error('"Değiştir" girişi bulunamadı'); }
        const transfer = new DataTransfer();
        transfer.items.add(file);
        input.files = transfer.files;
        input.dispatchEvent(new Event('change', { bubbles: true }));
        const done = await waitFor(function () {
            const img = previewOf(key);
            return img && img.src !== beforeSrc && img.complete && img.naturalWidth > 0;
        }, 60000);
        closeMenus();
        if (!done) throw new Error('IDS fotoğrafı değiştirmedi');
        await sleep(800);
    }

    // Sağ/sol bukkal karışmışsa (IDS ya da kırpma modeli şaşırmışsa) düzeltir; yön okumaları (items) fotoğrafla
    // birlikte taşınır: etiketleri değiştirilir. İki yuva da karşı yana ait çıkarsa yer değiştirilir; yalnız biri
    // yanlışsa ve karşı yuva boşsa kare oraya taşınır; başka durumlarda dokunulmaz (uyarı kalır).
    // Dönüş: yuvalar değiştiyse true.
    async function fixBuccalSides(items) {
        const info = {};
        ['buccal_right', 'buccal_left'].forEach(function (key) {
            const item = items.find(function (it) { return it.slot === key; });
            if (item && item.is_photo) info[key] = { item: item, side: buccalSideOf(item) };
        });
        const R = info.buccal_right;
        const L = info.buccal_left;
        let plan = null;
        if (R && L && R.side === 'buccal_left' && L.side === 'buccal_right') {
            plan = { type: 'swap' };
        } else if (R && R.side === 'buccal_left' && !L && !tileOf('buccal_left')) {
            plan = { type: 'move', from: 'buccal_right', to: 'buccal_left' };
        } else if (L && L.side === 'buccal_right' && !R && !tileOf('buccal_right')) {
            plan = { type: 'move', from: 'buccal_left', to: 'buccal_right' };
        } else if (R && L && R.side && L.side && R.side === L.side) {
            plan = { type: 'replace', key: R.side === 'buccal_left' ? 'buccal_right' : 'buccal_left' };
        }
        if (!plan) return false;
        const notes = state.crop ? state.crop.notes : [];
        if (plan.type === 'swap') {
            const fromR = await cropItemOfSlot('buccal_right');
            const fromL = await cropItemOfSlot('buccal_left');
            if (!fromR || !fromL || fromR === fromL) {
                notes.push('Sağ ve sol bukkal yer değiştirmiş görünüyor ama dosyalar eşlenemedi; elle değiştirin');
                return false;
            }
            setStatus('Sağ ve sol bukkal yer değiştirmiş görünüyor; yuvalar değiştiriliyor…');
            let replaced = false;
            try {
                await replaceInSlot('buccal_right', fromL.file);
                replaced = true;
                await replaceInSlot('buccal_left', fromR.file);
            } catch (error) {
                if (replaced) { try { await replaceInSlot('buccal_right', fromR.file); } catch (e) { /* elle düzeltilir */ } }
                notes.push('Sağ/sol bukkal yer değiştirilemedi (' + error.message + '); elle değiştirin');
                return false;
            }
            R.item.slot = 'buccal_left';
            L.item.slot = 'buccal_right';
            notes.push(fromR.name + ' ve ' + fromL.name + ': sağ/sol bukkal karışmıştı, yuvalar değiştirildi');
            return true;
        }
        if (plan.type === 'replace') {
            const crop = state.crop;
            if (!crop || !crop.items || !window.idsfyCrop) return false;
            const side = plan.key === 'buccal_right' ? 'sağ' : 'sol';
            const current = {};
            for (const key of ['buccal_right', 'buccal_left']) {
                const img = previewOf(key);
                if (!img) continue;
                const blob = await (await fetch(img.src, { credentials: 'include' })).blob();
                (await window.idsfyCrop.matchGroup(blob, crop.items.filter(function (it) { return it.file; })))
                    .forEach(function (it) { current[it.name] = true; });
            }
            const candidate = bestOf(crop.items.filter(function (it) { return it.file && it.slot === plan.key && !current[it.name]; }));
            if (!candidate) {
                notes.push('Sağ ve sol bukkal aynı yana ait görünüyor ve ' + side + ' bukkal için başka kare bulunamadı; elle değiştirin');
                return false;
            }
            setStatus('İki bukkal aynı yana ait görünüyor; ' + side + ' bukkal yuvası ' + candidate.name + ' ile değiştiriliyor…');
            try {
                await replaceInSlot(plan.key, candidate.file);
                // Yeni karenin yönü yeniden okunur (eski okuma eski fotoğrafa aitti).
                const fresh = await previewImage(plan.key);
                const reread = fresh ? await askOrientation([fresh]) : null;
                const at = items.findIndex(function (it) { return it.slot === plan.key; });
                if (reread && reread[0] && at >= 0) { reread[0].slot = plan.key; items[at] = reread[0]; }
            } catch (error) {
                notes.push(side + ' bukkal yuvası değiştirilemedi (' + error.message + '); elle değiştirin');
                return false;
            }
            notes.push(candidate.name + ': iki bukkal aynı yana ait göründüğünden ' + side + ' bukkal yuvasına alındı');
            return true;
        }
        const found = await cropItemOfSlot(plan.from);
        if (!found) {
            notes.push('Bukkal fotoğraf karşı yana ait görünüyor ama dosyası eşlenemedi; elle taşıyın');
            return false;
        }
        setStatus('Bukkal fotoğraf karşı yana ait görünüyor; taşınıyor…');
        try {
            await uploadToEmptySlot(plan.to, found.file);
            await deleteSlot(tileOf(plan.from), plan.from);
        } catch (error) {
            notes.push(found.name + ': karşı bukkal yuvasına taşınamadı (' + error.message + '); elle taşıyın');
            return false;
        }
        info[plan.from].item.slot = plan.to;
        notes.push(found.name + ': karşı yana ait olduğundan ' + (plan.to === 'buccal_right' ? 'sağ' : 'sol') + ' bukkal yuvasına taşındı');
        return true;
    }

    // Adaylar arasından en net ve pozlaması dengeli olan (item.score, crop.js qualityScore); eşitse ilk.
    function bestOf(list) {
        let best = null;
        list.forEach(function (it) {
            if (!best || (Number(it.score) || 0) > (Number(best.score) || 0)) best = it;
        });
        return best;
    }

    // Yuvanın türü: oklüzal (üst/alt), bukkal (sağ/sol) ya da önden ağız içi.
    function slotKind(slot) {
        return /^occlussal_/.test(slot) ? 'occlusal' : /^buccal_/.test(slot) ? 'buccal' : slot;
    }

    // Hangi kareler hangi yuvaya girmeli (saf planlama; test edilebilir). slots[anahtar] = { filled: IDS yuvayı
    // doldurmuş, labels: yuvadaki karenin (ikizlerse tüm ikizlerin) kırpma aşamasındaki hedef yuvaları (eşleşmediyse
    // yok), names: yuvadaki karenin (ikizlerin) adları }; items: kırpılmış kareler (slot = hedef yuva). Dönüş:
    // { deletes: [anahtar], uploads: [{ key, item }] }.
    // HİÇBİR ŞEY SİLİNMEZ: IDS'in seçimleri büyük çoğunlukla doğru, kırpma modelinin etiketi ise güvenilmezdi (üç alt
    // oklüzali "üst" demişti; IDS doğru yerleştirmişti ve doğru kareler silinmişti). deletes yalnız UYARI içindir:
    // farklı türde görünen karelerin yuvaları. Yalnızca gerçekten boş kalan yuvaya, hedefi o yuva olan, henüz
    // yerleşmemiş (en iyi) kare yüklenir.
    function planSlots(keys, slots, items) {
        const placed = {};
        const deletes = keys.filter(function (key) {
            const s = slots[key];
            if (!(s && s.filled && s.labels && s.labels.length)) return false;
            const kinds = s.labels.map(slotKind).filter(function (k, i, all) { return all.indexOf(k) === i; });
            return kinds.length === 1 && kinds[0] !== slotKind(key);
        });
        keys.forEach(function (key) {
            const s = slots[key];
            if (s && s.filled) (s.names || []).forEach(function (name) { placed[name] = true; });
        });
        const uploads = [];
        keys.forEach(function (key) {
            const s = slots[key];
            if (s && s.filled) return;
            const item = bestOf(items.filter(function (it) { return it.slot === key && !placed[it.name]; }));
            if (item) { placed[item.name] = true; uploads.push({ key: key, item: item }); }
        });
        return { deletes: deletes, uploads: uploads };
    }

    // IDS'in sınıflandırıcısı sıkı kırpılmış kareleri yanlış yuvaya koyabiliyor ya da hiç koymayabiliyor (29 Ekim
    // 2026: önden ağız içi kare hiçbir yuvaya girmedi, bir oklüzal sağ bukkale girdi). Yükleme durulunca yuvalar
    // kırpma aşamasında belirlenen hedef yuvalarla karşılaştırılır (sağ/sol bukkal yön okumasından hesaplanır).
    // Önizleme imzayla kırpılmış kareye eşlenir; ikiz çekimler aynı hedefe aitse yerleşmiş sayılır (kopya yüklenmez).
    // Dönüş: bir şey değiştiyse true (yükleme yeniden beklenir).
    async function reconcileSlots() {
        const crop = state.crop;
        if (!crop || !crop.items || !window.idsfyCrop) return false;
        const items = crop.items.filter(function (it) { return it.file && it.slot !== 'other'; });
        if (!items.length) return false;
        const keys = SLOTS.map(function (s) { return s.key; });
        const slots = {};
        for (const key of keys) {
            const img = previewOf(key);
            slots[key] = { filled: !!tileOf(key) };
            if (!img) continue;
            try {
                const blob = await (await fetch(img.src, { credentials: 'include' })).blob();
                const group = await window.idsfyCrop.matchGroup(blob, items);
                if (group.length) {
                    slots[key].names = group.map(function (it) { return it.name; });
                    slots[key].labels = group.map(function (it) { return it.slot; });
                }
            } catch (error) { /* eşlenemeyen yuvaya dokunulmaz */ }
        }
        const plan = planSlots(keys, slots, items);
        const label = function (key) { return SLOTS.find(function (s) { return s.key === key; }).label; };
        let changed = false;
        // Silinmez; yalnız uyarı (kullanıcı kontrol eder).
        plan.deletes.forEach(function (key) {
            crop.notes.push(slots[key].names.join('/') + ': ' + label(key) + ' yuvasındaki kare başka türde görünüyor, kontrol edin (silinmedi)');
        });
        for (const up of plan.uploads) {
            setStatus(label(up.key) + ' yuvası boş; ' + up.item.name + ' doğrudan yükleniyor…');
            try {
                await uploadToEmptySlot(up.key, up.item.file);
                crop.notes.push(up.item.name + ': ' + label(up.key) + ' yuvasına doğrudan yüklendi');
                changed = true;
            } catch (error) {
                crop.notes.push(up.item.name + ': ' + label(up.key) + ' yuvasına doğrudan yüklenemedi (' + error.message + ')');
            }
        }
        return changed;
    }

    // Sonuç: tüm yuvalar uyarısız düzeltildiyse true.
    // auto: kendiliğinden çağrıldı ("Durdur" basılırsa kalan yuvalar bırakılır); düğmeyle
    // çağrıldığında durdurma bayrağına bakılmaz.
    async function onFix(auto) {
        let clean = false;
        let halted = false;
        state.busy = true;
        state.results = {};
        render();
        try {
            setStatus('Ağız içi fotoğraflar okunuyor…');
            const images = [];
            for (const slot of SLOTS) {
                const image = await previewImage(slot.key);
                if (image) images.push(image);
            }
            if (!images.length) throw new Error('Ağız içi yuvalarda fotoğraf yok.');
            setStatus('Yapay zeka ' + images.length + ' fotoğrafın yönüne bakıyor…');
            const items = await askOrientation(images);
            try {
                if (await fixBuccalSides(items)) setStatus('Sağ/sol bukkal düzeltildi; yönler ayarlanıyor…');
            } catch (error) {
                if (state.crop) state.crop.notes.push('Sağ/sol bukkal denetimi yapılamadı (' + error.message + ')');
            }
            let failed = 0;
            for (const slot of SLOTS) {
                if (auto && state.stopped) { halted = true; break; }
                const item = items.find(function (it) { return it.slot === slot.key; });
                if (!item) continue;
                if (!item.is_photo) {
                    state.results[slot.key] = { ok: true, text: 'tarama görüntüsü, dokunulmadı' };
                    continue;
                }
                const target = decide(slot.key, item);
                if (!target) {
                    failed++;
                    state.results[slot.key] = { ok: false, text: 'yön okunamadı, elle düzeltin' };
                    continue;
                }
                setStatus(slot.label + ' düzeltiliyor…');
                try {
                    await applyOrientation(slot.key, target);
                    state.results[slot.key] = { ok: true, text: describe(target), warning: target.warning };
                } catch (error) {
                    failed++;
                    state.results[slot.key] = { ok: false, text: error.message };
                }
                render();
            }
            setStatus(halted ? 'Durduruldu; kalan yuvalar düzeltilmedi.' : failed
                ? failed + ' yuva düzeltilemedi; elle kontrol edin.'
                : 'Yönler düzeltildi. Yuvaları gözden geçirin.', failed > 0);
            // IDS yuvada çözünürlük ünlemi (kırmızı !) verdiyse satıra uyarı olarak yazılır; kırpılmış dosya boyutu da eklenir.
            try {
                for (const key of idsResolutionWarnings()) {
                    const found = await cropItemOfSlot(key);
                    const size = found && found.width ? ' (yüklenen kırpma ' + found.width + 'x' + found.height + ' px)' : '';
                    const text = 'IDS çözünürlük ünlemi verdi' + size + '; fotoğraf IDS gereksinimini karşılamıyor olabilir';
                    const row = state.results[key] || { ok: true, text: 'IDS ünlemi' };
                    row.warning = row.warning ? row.warning + '; ' + text : text;
                    state.results[key] = row;
                }
                render();
            } catch (error) { /* ünlem denetimi başarısızsa sessiz geçilir */ }
            const warned = Object.keys(state.results).filter(function (key) {
                return state.results[key].warning;
            }).length;
            clean = !failed && !warned && !halted;
        } catch (error) {
            setStatus('Hata: ' + error.message, true);
        }
        state.busy = false;
        render();
        return clean;
    }

    // Yükleme ve düzeltme kendiliğinden yapıldıysa sonucu duyurur: reçete akışı (rx.js)
    // bunu dinleyip ilerler; hasta sihirbazında "İleri"ye burada basılır. Uyarı ya da
    // hata varsa ilerlenmez.
    // Bir yuvadaki fotoğrafı siler: kalem menüsü > son düğme "Sil" > onay penceresinde "Sil".
    async function deleteSlot(tile, slotName) {
        const pencil = tile.querySelector('[class*="UploadedPhoto-editButton"]');
        if (!pencil) throw new Error('düzenle düğmesi bulunamadı');
        if (visibleDialog()) throw new Error('açık bir pencere var');
        closeMenus();
        await sleep(200);
        pencil.click();
        if (!(await waitFor(function () { return !!menuButtons(); }, 3000))) throw new Error('düzenleme menüsü açılmadı');
        const buttons = menuButtons();
        const remove = buttons[buttons.length - 1];
        if (!/sil|delete|remove|löschen/i.test(remove.textContent)) throw new Error('menüde "Sil" bulunamadı');
        remove.click();
        const confirmButton = function () {
            const dialog = Array.from(document.querySelectorAll('[role="dialog"]')).find(function (d) { return d.offsetWidth > 0; });
            if (!dialog) return null;
            const list = Array.from(dialog.querySelectorAll('button'));
            return list.find(function (b) { return /^\s*(sil|delete|remove|evet|yes)\s*$/i.test(b.textContent); }) || list[list.length - 1] || null;
        };
        if (!(await waitFor(function () { return !!confirmButton(); }, 3000))) throw new Error('silme onayı açılmadı');
        confirmButton().click();
        // Silme sunucuya gider; sihirbazda birkaç saniye sürebilir. Yuva boş girişe dönünce biter.
        const emptied = function () {
            const stillFilled = document.querySelector('input[type="file"][id$="-' + slotName + '-uploaded-photo-input"]');
            const empty = document.querySelector('input[type="file"][id$="-' + slotName + '-uploader-input"]');
            return !stillFilled || !!empty;
        };
        if (!(await waitFor(emptied, 25000))) throw new Error('IDS fotoğrafı silmedi');
        await waitFor(function () { return !visibleDialog(); }, 5000);
        await sleep(600);
    }

    function visibleDialog() {
        return Array.from(document.querySelectorAll('[role="dialog"]')).find(function (d) { return d.offsetWidth > 0; }) || null;
    }

    // Tüm dolu yuvaları sırayla boşaltır (hasta sihirbazı ve reçete). Kullanıcı düğmesiyle çalışır.
    async function deleteAll() {
        state.busy = true;
        state.results = {};
        render();
        let removed = 0;
        const failed = [];
        try {
            // Dolu yuvaların adları baştan alınır; her yuva en çok iki kez denenir, başarısız
            // olan atlanıp kalanlara geçilir.
            const names = Array.from(document.querySelectorAll('input[type="file"][id$="-uploaded-photo-input"]'))
                .map(function (input) { return input.id.replace(/^.*-next-/, '').replace('-uploaded-photo-input', ''); });
            for (const slotName of names) {
                let done = false;
                let lastError = null;
                for (let attempt = 0; attempt < 2 && !done; attempt++) {
                    const filled = document.querySelector('input[type="file"][id$="-' + slotName + '-uploaded-photo-input"]');
                    if (!filled) { done = true; break; }
                    setStatus('Siliniyor: ' + slotName + (attempt ? ' (yeniden)' : '') + '…');
                    try {
                        await deleteSlot(filled.parentElement, slotName);
                        removed++;
                        done = true;
                    } catch (error) {
                        lastError = error.message;
                        closeMenus();
                        await sleep(1500);
                    }
                }
                if (!done) failed.push(slotName + ' (' + lastError + ')');
            }
            closeMenus();
            setStatus(failed.length
                ? removed + ' fotoğraf silindi; silinemeyen: ' + failed.join(', ') + '. Bunları elle silin.'
                : removed + ' fotoğraf silindi.', failed.length > 0);
        } finally {
            state.busy = false;
            render();
        }
    }

    // Yön düzeltmesinden sonra ilerlemeden önce kırpma için beklenir (kullanıcı kararı): "Kırptım,
    // devam et" ya da "Kırpmadan devam et" seçilince sonuç duyurulur ve akış sürer.
    function askCrop(clean) {
        if (state.stopped) return;
        const auto = state.crop;
        if (auto) {
            // Kendiliğinden kırpıldı: yuvalar kontrol edilir; beğenilmezse orijinaller yeniden yüklenir.
            setStatus((clean ? 'Yönler düzeltildi. ' : 'Yön düzeltmesi uyarılarla bitti. ') +
                'Fotoğraflar yüklenmeden önce kendiliğinden kırpıldı (' + auto.cropped + '/' + auto.total +
                (auto.timing ? ', ' + auto.timing.total + ' sn' : '') + '). Yuvaları kontrol edin.' + (auto.notes.length ? ' Notlar: ' + auto.notes.join('; ') : ''));
            showActions([
                { text: 'Devam et', run: function () { showActions([]); announce(clean); } },
                {
                    text: 'Kırpılmamış halleriyle yeniden yükle',
                    run: async function () {
                        showActions([]);
                        const bridge = document.getElementById('idsfy-bridge');
                        await deleteAll();
                        state.skipCrop = true;
                        onFolder(auto.originals, bridge, true);
                    }
                }
            ]);
            return;
        }
        setStatus((clean ? 'Yönler düzeltildi. ' : 'Yön düzeltmesi uyarılarla bitti. ') +
            'Fotoğrafları kırpmanız bekleniyor (yuvada kalem > Kırp). Bitince seçin:');
        showActions([
            { text: 'Kırptım, devam et', run: function () { showActions([]); announce(clean); } },
            { text: 'Kırpmadan devam et', run: function () { showActions([]); announce(clean); } }
        ]);
    }

    function showActions(list) {
        const area = panel.querySelector('.idsfy-actions');
        if (!area) return;
        area.textContent = '';
        list.forEach(function (action) {
            const button = el('button', 'idsfy-button', action.text);
            button.type = 'button';
            button.addEventListener('click', function () { action.run(); });
            area.appendChild(button);
        });
    }

    // Hasta birden fazla refinement görmüşse birden fazla refinement klasörü olabilir; hangisinin
    // kullanılacağı sorulur ve bu reçete için hatırlanır (CBCT yüklemesi de aynı seçimi kullanır).
    function refinementChoiceKey() {
        const params = new URLSearchParams(location.search);
        return 'idsfy-refinement-folder-' + (params.get('formId') || params.get('patientId') || '');
    }

    function askRefinementFolder(handle, choices, bridge, explicit) {
        setStatus('Birden fazla refinement klasörü var; fotoğrafları hangisinden alalım?');
        showActions(choices.map(function (name) {
            return {
                text: name,
                run: async function () {
                    sessionStorage.setItem(refinementChoiceKey(), name);
                    showActions([]);
                    setStatus('"' + name + '" klasörü okunuyor…');
                    try {
                        const files = await window.idsfyFolder.images(handle, 'refinement', name);
                        if (!files.length) { setStatus('"' + name + '" içinde fotoğraf yok.', true); return; }
                        onFolder(files, bridge, explicit);
                    } catch (error) {
                        setStatus('Klasör okunamadı: ' + error.message, true);
                    }
                }
            };
        }));
    }

    // Hangi fotoğraf kümesi: refinement reçetesinde hasta klasörünün "Refinement" alt klasörü,
    // yeni hastada "Başlangıç" alt klasörü ya da klasörün kendisi.
    function photoKind() {
        return /\/rx\/secondary\/additionalAligners\.action$/.test(location.pathname) ? 'refinement' : 'new';
    }

    function announce(clean) {
        document.documentElement.dataset.idsfyPhotos = clean ? 'ok' : 'check';
        document.dispatchEvent(new CustomEvent('idsfy-photos-done'));
        if (!clean || state.stopped || !/\/patient\/editPatient\.action$/.test(location.pathname)) return;
        const next = document.getElementById('uploadButton') || document.querySelector('.next-button');
        if (next && !next.disabled) {
            setStatus('Yönler düzeltildi. Sonraki adıma geçiliyor…');
            setTimeout(function () { if (!state.stopped) next.click(); }, 1500);
        }
    }

    function buildPanel() {
        panel = el('div', 'idsfy-panel');
        const head = el('div', 'idsfy-head');
        head.appendChild(el('span', '', 'IDS Foto Yükleyici'));
        const toggle = el('button', 'idsfy-toggle', '–');
        toggle.type = 'button';
        toggle.addEventListener('click', function () {
            toggle.textContent = panel.classList.toggle('idsfy-collapsed') ? '+' : '–';
        });
        head.appendChild(toggle);
        panel.appendChild(head);

        const body = el('div', 'idsfy-body');
        panel.appendChild(body);

        // Sayfa dünyasındaki köprü (page.js) dosyaları bu girişten okur.
        const bridge = el('input', 'idsfy-picker');
        bridge.type = 'file';
        bridge.multiple = true;
        bridge.id = 'idsfy-bridge';
        body.appendChild(bridge);

        const picker = el('input', 'idsfy-picker');
        picker.type = 'file';
        picker.multiple = true;
        picker.webkitdirectory = true;
        picker.setAttribute('aria-label', 'Hasta klasörü');
        picker.addEventListener('change', function () {
            if (picker.files.length) onFolder(picker.files, bridge, true);
            picker.value = '';
        });
        body.appendChild(picker);

        // Hastanın klasörü ana klasörde adından bulunup IDS'e bırakılır (gerekirse izin istenir);
        // bulunamazsa klasör seçme penceresi açılır. "Durdur" açıkken de çalışır.
        const choose = el('button', 'idsfy-button', 'Hasta klasörünü otomatik yükle');
        choose.type = 'button';
        choose.addEventListener('click', async function () {
            if (!(await dropRemembered(bridge, true, true))) picker.click();
        });
        body.appendChild(choose);

        const manual = el('button', 'idsfy-button', 'Klasörü elle seç');
        manual.type = 'button';
        manual.addEventListener('click', function () { picker.click(); });
        body.appendChild(manual);

        const fix = el('button', 'idsfy-button', 'Yönleri düzelt');
        fix.type = 'button';
        fix.addEventListener('click', function () { onFix(); });
        body.appendChild(fix);

        const remove = el('button', 'idsfy-button idsfy-danger', 'Tüm fotoları sil');
        remove.type = 'button';
        remove.addEventListener('click', function () {
            const count = document.querySelectorAll('input[type="file"][id$="-uploaded-photo-input"]').length;
            if (!count) { setStatus('Silinecek fotoğraf yok.'); return; }
            if (!window.confirm(count + ' fotoğraf IDS\'ten silinecek. Emin misiniz?')) return;
            deleteAll();
        });
        body.appendChild(remove);

        // Durdur / Devam et: durdurulunca kullanıcı fotoğrafları elle yükleyip İleri'ye kendisi
        // basar; "Devam et" bekleyen yüklemeyi izleyip yönleri düzeltir ve ilerler.
        const stopButton = el('button', 'idsfy-button idsfy-stop', 'Durdur');
        stopButton.type = 'button';
        stopButton.addEventListener('click', function () {
            state.stopped = !state.stopped;
            if (state.stopped) {
                sessionStorage.setItem(stopKey(), '1');
                render();
                setStatus('Durduruldu. Fotoğrafları elle yükleyip "İleri"ye siz basın; isterseniz ' +
                    '"2. Yönleri düzelt"i kullanın. Kendiliğinden sürmesi için "Devam et".');
            } else {
                sessionStorage.removeItem(stopKey());
                render();
                setStatus('Sürdürülüyor; yükleme bitince yönler düzeltilecek…');
                fixWhenUploaded(0);
            }
        });
        body.appendChild(stopButton);

        body.appendChild(el('div', 'idsfy-status', 'Hastanın fotoğraf klasörünü seçin.'));
        body.appendChild(el('div', 'idsfy-actions'));
        body.appendChild(el('div', 'idsfy-list'));

        document.body.appendChild(panel);
        render();
        // Ortak ana klasörün izni köprü kutusundan verilince klasör kendiliğinden bırakılır.
        document.addEventListener('idsfy-folder-ready', function () {
            if (state.stopped || state.busy) return;
            if (document.querySelector('input[type="file"][id$="-uploaded-photo-input"]')) return;
            dropRemembered(bridge, false);
        });
        rxStopped().then(function (stopped) {
            if (stopped || sessionStorage.getItem(stopKey())) {
                state.stopped = true;
                render();
                setStatus(stopped
                    ? 'Form doldurucu durduruldu; fotoğraflar size bırakıldı ("1. Hasta klasörünü yükle" ile yine yüklenebilir).'
                    : 'Bu hastada fotoğraf adımı durdurulmuştu; klasör kendiliğinden bırakılmaz. "Devam et" ile sürdürün.');
                return;
            }
            dropRemembered(bridge, false);
        });
    }

    // Hastanın klasörü ana klasörde adından bulunabiliyorsa (ya da bu hasta için elle
    // seçilmişse) sorulmadan IDS'e bırakılır. Bulunamazsa false döner.
    async function dropRemembered(bridge, mayAskPermission, explicit) {
        try {
            let found = await window.idsfyFolder.resolve();
            if (found.status === 'needs-permission' && mayAskPermission && await window.idsfyFolder.grant()) {
                found = await window.idsfyFolder.resolve();
            }
            if (found.status === 'needs-permission') {
                setStatus(found.shared
                    ? 'Klasör izni gerekiyor: sağ üstteki kutuda "İzin ver"e basın.'
                    : 'Klasör izni gerekiyor: "Hasta klasörünü otomatik yükle"ye basın.');
                return false;
            }
            if (found.status === 'no-root') {
                if (!explicit) {
                    setStatus('Ana klasör bu bilgisayarda seçilmemiş; "Hasta klasörünü otomatik yükle"ye basın.');
                    return false;
                }
                // Ana klasör (hasta klasörlerinin durduğu üst klasör) bir kez seçilir, sonra hasta aranır.
                setStatus('Ana klasör henüz seçilmedi: hasta klasörlerinin durduğu üst klasörü seçin.');
                await window.idsfyFolder.pickRoot();
                return dropRemembered(bridge, true, true);
            }
            if (found.status === 'not-found') {
                setStatus('"' + found.root + '" içinde "' + window.idsfyFolder.patientName() + '" adına uyan klasör yok' +
                    (explicit ? '; hastanın klasörünü elle seçin.' : '.'), true);
                return false;
            }
            if (found.status === 'ambiguous') {
                setStatus('Birden çok klasör uyuyor: ' + found.names.join(', ') +
                    (explicit ? '; hastanın klasörünü elle seçin.' : '.'), true);
                return false;
            }
            if (found.status !== 'ok') return false;
            const kind = photoKind();
            setStatus('"' + found.handle.name + '" klasörü okunuyor…');
            const choice = kind === 'refinement' ? sessionStorage.getItem(refinementChoiceKey()) : null;
            const files = await window.idsfyFolder.images(found.handle, kind, choice);
            if (files.choices && files.choices.length) {
                askRefinementFolder(found.handle, files.choices, bridge, explicit);
                return true;
            }
            if (!files.length) {
                setStatus(kind === 'refinement'
                    ? '"' + found.handle.name + '" içinde "Refinement" alt klasörü ya da içinde fotoğraf bulunamadı.'
                    : '"' + found.handle.name + '" içinde (ya da "Başlangıç" alt klasöründe) fotoğraf bulunamadı.', true);
                return true;
            }
            onFolder(files, bridge, explicit);
            return true;
        } catch (error) {
            setStatus('Hasta klasörü okunamadı; klasörü elle seçin.', true);
            return false;
        }
    }

    // IDS adımlar arasında sayfayı yeniden çizdiği için panel, Fotoğraflar adımının
    // yükleme girişleri göründükçe gösterilir.
    setInterval(function () {
        const show = onPhotosStep();
        if (show && !panel) buildPanel();
        if (panel) panel.style.display = show ? '' : 'none';
    }, 1000);
})();
