// Fotoğraf kırpma ve yön yardımcıları (yerleştirme SONRASI akış, 0.32.0, 30 Ekim 2026).
// Kullanıcının gözlemi: kırpılmamış fotoğraflarla IDS'in yerleştirmesi ve yön okuması çok daha iyi çalışıyordu; kırpma IDS'ten
// önce yapılınca sınıflandırıcı ve yön okuması yüz, ekartör, çene gibi ipuçlarını kaybediyordu. Bu yüzden:
//   1) Orijinaller IDS'e olduğu gibi bırakılır (IDS yerleştirir),
//   2) yön, yuvası bilinen orijinalin küçük karesinden okunur (content.js),
//   3) yuvası ve yönü bilinen kare için kırpma kutusu/ölçümleri modelden alınır (readBoxes, yuva etiketi verilir),
//   4) kare tuvalde kırpılır, döndürülür (oklüzalde aynalanır) ve IDS'teki yuvaya "Değiştir" ile konur (content.js).
// Çerçeve kuralları (intraoralFrame, occlusalBox, relaxBox, yüz 2:3) kullanıcıyla ayarlandı; dosyalar klasörde değişmez.
(function () {
    'use strict';

    const SETTINGS = {
        maxSide: 1024,        // modele giden karenin uzun kenarı (piksel)
        margin: 0,            // ağız içi pay (%): çerçeveyi ekartör kolları belirlediği için pay yok (kullanıcı, 29 Ekim 2026)
        retractorKeep: 0.3,   // ekartör kolunun karede kalan payı (0.3 = kolun %30'u içeride)
        balance: 1.4,         // oklüzal düzlemin üstü/altı bu orandan dengesizse uzun tarafta dudak kıvrımı esas alınır
        teethPad: 0.015,      // diş sınırı emniyeti, dikey (görüntü yüksekliğinin kesri)
        teethPadX: 0.01,      // diş sınırı emniyeti, yatay (görüntü genişliğinin kesri)
        maxAspect: 2.0,       // ağız içi önden/yan kırpmada en/boy en çok bu kadar (dişleri saran yatay şerit olmasın)
        minOutW: 1000,        // çıkış kırpmasının asgari genişliği/yüksekliği (piksel); IDS 1000x392'yi kabul etti, 800x314'e ünlem verdi
        minOutH: 500,
        roomH: 1.5,           // ağız içi önden/yan karede çerçeve yüksekliği en az diş yüksekliğinin bu katı
        roomW: 1.15,          // yalnız önden karede genişlik en az diş genişliğinin bu katı
        cropEffort: 'medium', // kırpma kutusu çağrısının effort değeri (low | medium | high)
        archEffort: 'medium', // oklüzal diş sırası kutusu okuması
        archModel: 'sonnet',  // opus | sonnet (Sonnet 2-4 sn, kutu kalitesi aynı)
        hedgeMs: 20000,       // >0: bu kadar ms içinde yanıtlanmayan model çağrısına ikinci istek açılır (0 = kapalı)
        minTilt: 0.3,         // bunun altındaki oklüzal düzlem eğimi düzeltilmez (derece)
        maxTilt: 20,          // oklüzal düzlem düzeltmesi en çok bu kadar derece
        occlusalMargin: 10,   // oklüzal: diş sınırının her kenarına eklenen pay (%)
        faceMargin: 10,       // yüz payı (%)
        faceRatio: 2 / 3,     // yüz en-boy (genişlik / yükseklik)
        groupSize: 6,         // sınıflandırmada model her istekte en çok bu kadar kareye bakar; gruplar aynı anda sorulur
        prepareParallel: 3,   // aynı anda çözülen tam boyutlu kare sayısı
        minConfidence: 0.4,   // sınıflandırmada altı "other" sayılır
        quality: 0.92         // kırpılmış JPEG kalitesi
    };
    const FACE = /^(profile|frontal)_/;
    const INTRAORAL = /^(labial|buccal)_/;
    const OCCLUSAL = /^occlussal_/;

    function num(v) { const n = Number(v); return isFinite(n) ? n : 0; }

    // Model çağrısı: hedgeMs > 0 ise bu süre içinde yanıtlanmayan çağrıya ikinci istek açılır ve ilk başarılı yanıt alınır
    // (aynı iş bazen 9 sn, bazen 50 sn sürüyor; kuyruk gecikmesini keser, yalnız yavaş çağrılarda ek maliyet).
    function sendHedged(message) {
        if (!(SETTINGS.hedgeMs > 0)) return send(message);
        return new Promise(function (resolve, reject) {
            let done = false, failures = 0, started = 1;
            const finish = function (ok, value) {
                if (done) return;
                if (ok) { done = true; clearTimeout(timer); resolve(value); return; }
                failures++;
                if (failures >= started) { done = true; clearTimeout(timer); reject(value); }
            };
            const run = function () { send(message).then(function (r) { finish(true, r); }, function (e) { finish(false, e); }); };
            const timer = setTimeout(function () { if (!done) { started++; run(); } }, SETTINGS.hedgeMs);
            run();
        });
    }

    function send(message) {
        return new Promise(function (resolve, reject) {
            if (!chrome.runtime || !chrome.runtime.id) {
                return reject(new Error('Eklenti güncellendi; bu sayfayı yenileyin (F5).'));
            }
            chrome.runtime.sendMessage(message, function (reply) {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!reply || !reply.ok) return reject(new Error(reply ? reply.error : 'yanıt yok'));
                resolve(reply);
            });
        });
    }

    // EXIF yönü uygulanmış kare: model kutuyu bu haliyle verir, kırpma da aynı haliyle yapılır.
    function bitmapOf(file) {
        return createImageBitmap(file, { imageOrientation: 'from-image' });
    }

    // Aynı görünümün tekrar çekimlerini karşılaştırmak için: 256 piksellik gri kareden ortalama parlaklık (0-255)
    // ve netlik (Laplace varyansı). Kıyas yalnızca aynı görünümün kareleri arasında anlamlıdır.
    function qualityOf(source) {
        const w = 256;
        const h = Math.max(8, Math.round(w * source.height / source.width));
        const c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        const ctx = c.getContext('2d');
        ctx.drawImage(source, 0, 0, w, h);
        const px = ctx.getImageData(0, 0, w, h).data;
        const gray = new Float32Array(w * h);
        let sum = 0;
        for (let i = 0; i < gray.length; i++) {
            gray[i] = px[i * 4] * 0.299 + px[i * 4 + 1] * 0.587 + px[i * 4 + 2] * 0.114;
            sum += gray[i];
        }
        let lap = 0, lap2 = 0, n = 0;
        for (let y = 1; y < h - 1; y++) {
            for (let x = 1; x < w - 1; x++) {
                const i = y * w + x;
                const v = 4 * gray[i] - gray[i - 1] - gray[i + 1] - gray[i - w] - gray[i + w];
                lap += v;
                lap2 += v * v;
                n++;
            }
        }
        const mean = lap / n;
        return { bright: sum / gray.length, sharp: lap2 / n - mean * mean };
    }

    // Aday sıralaması: pozlaması dengeli (ne karanlık ne patlamış) ve net olan önde.
    function qualityScore(it) {
        const exposure = Math.max(0.05, 1 - Math.abs((Number(it.bright) || 0) - 125) / 125);
        return (Number(it.sharp) || 0) * exposure;
    }

    // Küçük kare (modele gider) + imza (IDS önizlemesiyle eşleştirme için) + kalite ölçüleri. EXIF yönü uygulanmış.
    async function thumbnail(file) {
        const bitmap = await bitmapOf(file);
        try {
            const scale = Math.min(1, SETTINGS.maxSide / Math.max(bitmap.width, bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(bitmap.width * scale));
            canvas.height = Math.max(1, Math.round(bitmap.height * scale));
            canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
            const q = qualityOf(canvas);
            return { w: bitmap.width, h: bitmap.height, data: canvas.toDataURL('image/jpeg', 0.85).split(',')[1],
                sig: signatureOf(canvas, canvas.width, canvas.height), bright: q.bright, sharp: q.sharp };
        } finally {
            bitmap.close();
        }
    }

    // En çok `limit` iş aynı anda çalışır (tam boyutlu kareler bellekte büyüktür).
    function limiter(limit) {
        let active = 0;
        const queue = [];
        const next = function () {
            if (active >= limit || !queue.length) return;
            active++;
            const job = queue.shift();
            job.fn().then(job.resolve, job.reject).then(function () { active--; next(); });
        };
        return function (fn) {
            return new Promise(function (resolve, reject) { queue.push({ fn: fn, resolve: resolve, reject: reject }); next(); });
        };
    }

    // Klasördeki orijinalleri modele ve eşleştirmeye hazırlar: {name, file, w, h, thumb, sig, bright, sharp, score}. Dosyalar değişmez.
    async function prepare(files, progress) {
        const say = progress || function () {};
        const limit = limiter(SETTINGS.prepareParallel);
        let done = 0;
        return Promise.all(files.map(function (file) {
            return limit(async function () {
                const info = await thumbnail(file);
                done++;
                say('Fotoğraflar hazırlanıyor… (' + done + '/' + files.length + ')');
                return { name: file.name, file: file, w: info.w, h: info.h, thumb: info.data, sig: info.sig,
                    bright: info.bright, sharp: info.sharp, score: qualityScore(info) };
            });
        }));
    }

    // Kutu çok yatay ise (en/boy > maxAspect) boyu merkez etrafında genişletilir, çok küçükse (piksel) merkez etrafında büyütülür;
    // görüntü sınırında kaydırılır. Kutu kesirlerle, w/h ham kare pikselleridir.
    function relaxBox(box, w, h, maxAspect, minW, minH) {
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        const grow = function (lo, hi, want) {
            let a = lo, b = hi;
            if (b - a >= want) return [a, b];
            const c = (a + b) / 2;
            a = c - want / 2; b = c + want / 2;
            if (a < 0) { b -= a; a = 0; }
            if (b > 1) { a -= b - 1; b = 1; }
            return [Math.max(0, a), Math.min(1, b)];
        };
        if (maxAspect > 0 && (x1 - x0) * w / ((y1 - y0) * h) > maxAspect) {
            const r = grow(y0, y1, (x1 - x0) * w / maxAspect / h);
            y0 = r[0]; y1 = r[1];
        }
        if (minW > 0 && (x1 - x0) * w < minW) { const r = grow(x0, x1, minW / w); x0 = r[0]; x1 = r[1]; }
        if (minH > 0 && (y1 - y0) * h < minH) { const r = grow(y0, y1, minH / h); y0 = r[0]; y1 = r[1]; }
        return [x0, y0, x1, y1];
    }

    // Pay ve en-boy uygulanmış son kutu (kesirler). Görüntü dışına taşarsa kaydırılır, sığmazsa kırpılır.
    function finalBox(box, marginPct, ratio, w, h) {
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        [x0, y0, x1, y1] = [x0, y0, x1, y1].map(function (v) { return Math.min(1, Math.max(0, Number(v) || 0)); });
        if (x1 <= x0 || y1 <= y0) return null;
        const m = marginPct / 100;
        const bw = x1 - x0, bh = y1 - y0;
        x0 -= bw * m; x1 += bw * m; y0 -= bh * m; y1 += bh * m;
        if (ratio) {
            const pw = (x1 - x0) * w, ph = (y1 - y0) * h;
            if (pw / ph < ratio) {
                const nw = ph * ratio, cx = (x0 + x1) / 2 * w;
                x0 = (cx - nw / 2) / w; x1 = (cx + nw / 2) / w;
            } else {
                const nh = pw / ratio, cy = (y0 + y1) / 2 * h;
                y0 = (cy - nh / 2) / h; y1 = (cy + nh / 2) / h;
            }
        }
        if (x0 < 0) { x1 -= x0; x0 = 0; }
        if (y0 < 0) { y1 -= y0; y0 = 0; }
        if (x1 > 1) { x0 -= x1 - 1; x1 = 1; }
        if (y1 > 1) { y0 -= y1 - 1; y1 = 1; }
        return [Math.max(0, x0), Math.max(0, y0), Math.min(1, x1), Math.min(1, y1)];
    }

    // Ön ve yan ağız içi kare: çerçeve modelin kutusundan değil ölçümlerinden hesaplanır (kullanıcı ince
    // ayarı, 29 Ekim 2026: model "kolun yarısı içeride" kutusunu tutturamıyordu; ölçüm + hesap daha güvenilir).
    //   plane_x0..plane_y1 : oklüzal düzlemin iki ucu → eğim (sağa doğru aşağı = pozitif); görüntü kutu
    //                        merkezi (pivot) etrafında -eğim kadar döndürülür, düzlem yere paralel olur.
    //   arms[]             : ekartör kolu {x, top, bottom}; üst/alt kol düzleme göre ayrılır (kare ters
    //                        olsa da çalışır); kesme noktası kolun dişe bakan kenarından retractorKeep
    //                        oranında dışarıda; döndürülmüş karede y alınır, üst/alt kenar ortalamadır.
    //   lip_upper_y/lower  : dudak-dişeti kıvrımı; düzlemin üstü/altı çok dengesizse (balance) uzun tarafta
    //                        ekartör yerine bu kıvrım kenar olur (kullanıcı, 29 Ekim 2026).
    //   c_left/right_x     : C ekartörün iç bükey ucu → o yanın kenarı (C'nin sırtı ve yanak dışarıda).
    //   far_left/right_x   : karşı ekartörün dişe bakan kenarı → o yan dişe yaklaşır, karşı ekartör dışarıda.
    //   teeth_*            : diş tacı sınırı → emniyet, hiçbir diş kesilmez.
    // Döndürme köşeleri görüntü dışına taşırırsa o yan içeri çekilir (siyah köşe kalmasın).
    // Düzlem 45°'den eğikse (kare yan duruyor) ölçümlere güvenilmez, modelin kutusu olduğu gibi kalır.
    // w, h: görüntü boyutu (piksel). Dönüş: box döndürülmüş karede kesirler; tilt derece; pivot kesir.
    function intraoralFrame(item, w, h) {
        const box = [num(item.x0), num(item.y0), num(item.x1), num(item.y1)];
        const pivot = [(box[0] + box[2]) / 2, (box[1] + box[3]) / 2];
        let p0 = [num(item.plane_x0), num(item.plane_y0)], p1 = [num(item.plane_x1), num(item.plane_y1)];
        if (p0[0] > p1[0]) { const t = p0; p0 = p1; p1 = t; }
        const dx = (p1[0] - p0[0]) * w, dy = (p1[1] - p0[1]) * h;
        const hasPlane = Math.hypot(dx, dy) > 0.05 * Math.min(w, h);
        const angle = hasPlane ? Math.atan2(dy, dx) * 180 / Math.PI : 0;
        const sideways = Math.abs(angle) > 45;
        let tilt = sideways ? 0 : angle;
        if (Math.abs(tilt) < SETTINGS.minTilt || Math.abs(tilt) > SETTINGS.maxTilt) tilt = 0;
        const rad = -tilt * Math.PI / 180, cos = Math.cos(rad), sin = Math.sin(rad);
        const px = pivot[0] * w, py = pivot[1] * h;
        // Noktanın döndürülmüş karedeki x'i / y'si (kesir) ve döndürülmüş karedeki noktanın orijinalde içeride olup olmadığı.
        const rotX = function (x, y) { const X = x * w - px, Y = y * h - py; return (X * cos - Y * sin + px) / w; };
        const rotY = function (x, y) { const X = x * w - px, Y = y * h - py; return (X * sin + Y * cos + py) / h; };
        const inside = function (x, y) {
            const X = x * w - px, Y = y * h - py;
            const ox = (px + X * cos + Y * sin) / w, oy = (py - X * sin + Y * cos) / h;
            return ox >= 0 && ox <= 1 && oy >= 0 && oy <= 1;
        };
        const planeY = function (x) {
            return hasPlane ? p0[1] + (x - p0[0]) * (p1[1] - p0[1]) / (p1[0] - p0[0]) : pivot[1];
        };
        let x0 = box[0], y0 = box[1], x1 = box[2], y1 = box[3];
        const arms = [];
        const used = { lip: '', sides: [] };
        let teeth = null, lips = null, sides = null;
        if (!sideways) {
            // Üst/alt kenar: ekartör kollarının kesme noktaları (döndürülmüş karede, ortalama).
            (Array.isArray(item.arms) ? item.arms : []).forEach(function (arm) {
                const x = num(arm.x), top = num(arm.top), bottom = num(arm.bottom), keep = SETTINGS.retractorKeep;
                if (!(bottom > top) || bottom - top > 0.25) return;
                const upper = (top + bottom) / 2 < planeY(x);
                const cut = upper ? bottom - keep * (bottom - top) : top + keep * (bottom - top);
                arms.push({ x: x, top: top, bottom: bottom, cut: cut, upper: upper, y: rotY(x, cut) });
            });
            const mean = function (a) { return a.reduce(function (s, v) { return s + v; }, 0) / a.length; };
            const ups = arms.filter(function (a) { return a.upper; }).map(function (a) { return a.y; });
            const lows = arms.filter(function (a) { return !a.upper; }).map(function (a) { return a.y; });
            if (ups.length) y0 = mean(ups);
            if (lows.length) y1 = mean(lows);
            // Denge: düzlemin üstü ile altı çok dengesizse uzun tarafta ekartör yerine dudak-dişeti kıvrımı.
            const lu = num(item.lip_upper_y), ll = num(item.lip_lower_y);
            lips = [lu, ll];
            if (hasPlane) {
                const cx = (p0[0] + p1[0]) / 2;
                const pc = rotY(cx, planeY(cx));
                const up = pc - y0, down = y1 - pc;
                if (up > 0 && down > 0) {
                    if (up > down * SETTINGS.balance && lu > 0) {
                        const yl = rotY(cx, lu);
                        if (yl > y0 && yl < pc) { y0 = yl; used.lip = 'üst'; }
                    } else if (down > up * SETTINGS.balance && ll > 0) {
                        const yl = rotY(cx, ll);
                        if (yl < y1 && yl > pc) { y1 = yl; used.lip = 'alt'; }
                    }
                }
            }
            // Yanlar: C'nin iç bükey ucu (C'nin sırtı dışarıda), karşı ekartörün dişe bakan kenarı (karşı ekartör dışarıda).
            sides = { cl: num(item.c_left_x), fl: num(item.far_left_x), cr: num(item.c_right_x), fr: num(item.far_right_x) };
            [[sides.cl, 'sol C'], [sides.fl, 'sol karşı ekartör']].forEach(function (c) {
                if (c[0] > 0 && c[0] < 1) { const r = rotX(c[0], pivot[1]); if (r > x0) { x0 = r; used.sides.push(c[1]); } }
            });
            [[sides.cr, 'sağ C'], [sides.fr, 'sağ karşı ekartör']].forEach(function (c) {
                if (c[0] > 0 && c[0] < 1) { const r = rotX(c[0], pivot[1]); if (r < x1) { x1 = r; used.sides.push(c[1]); } }
            });
            // Diş emniyeti: hiçbir diş kesilmez.
            const tt = num(item.teeth_top), tb = num(item.teeth_bottom), tl = num(item.teeth_left), tr = num(item.teeth_right);
            if (tb > tt) {
                teeth = [tt, tb];
                y0 = Math.min(y0, rotY(pivot[0], tt) - SETTINGS.teethPad);
                y1 = Math.max(y1, rotY(pivot[0], tb) + SETTINGS.teethPad);
            }
            if (tr > tl) {
                x0 = Math.min(x0, rotX(tl, pivot[1]) - SETTINGS.teethPadX);
                x1 = Math.max(x1, rotX(tr, pivot[1]) + SETTINGS.teethPadX);
            }
            // Önden ağız içi: orta hat (üst orta kesiciler arası; ölçülemezse diş sınırının ortası) ortada, dişlerle çerçeve
            // arasında sağ ve solda eşit mesafe. Çerçeve orta hat etrafında simetrik yapılır (geniş olan yan esas alınır, diş
            // kesilmez); orta hat görüntü kenarına yakınsa ya da diş sığmıyorsa simetri uygulanmaz.
            let symmetric = false;
            if (/^labial_/.test(item.slot || '')) {
                const midRaw = num(item.midline_x);
                const c = midRaw > 0 && midRaw < 1 ? rotX(midRaw, pivot[1]) : (tr > tl ? rotX((tl + tr) / 2, pivot[1]) : (x0 + x1) / 2);
                let hw = Math.max(c - x0, x1 - c);
                const fits = Math.min(c, 1 - c);
                const need = tr > tl ? Math.max(c - rotX(tl, pivot[1]), rotX(tr, pivot[1]) - c) + SETTINGS.teethPadX : 0;
                if (c > 0 && c < 1 && fits >= need && fits > 0.1) {
                    hw = Math.min(hw, fits);
                    x0 = c - hw;
                    x1 = c + hw;
                    symmetric = true;
                }
            }
            // Döndürme köşeleri görüntü dışına taşırırsa yanlar içeri çekilir (siyah köşe kalmasın; en çok %25); simetrik
            // çerçevede iki yan birlikte çekilir.
            if (tilt) {
                const limit0 = x0 + (x1 - x0) * 0.25, limit1 = x1 - (x1 - x0) * 0.25;
                if (symmetric) {
                    while (x0 < limit0 && !(inside(x0, y0) && inside(x0, y1) && inside(x1, y0) && inside(x1, y1))) { x0 += 0.003; x1 -= 0.003; }
                } else {
                    while (x0 < limit0 && !(inside(x0, y0) && inside(x0, y1))) x0 += 0.003;
                    while (x1 > limit1 && !(inside(x1, y0) && inside(x1, y1))) x1 -= 0.003;
                }
            }
        }
        if (!(y1 - y0 > 0.1) || !(x1 - x0 > 0.2)) { x0 = box[0]; y0 = box[1]; x1 = box[2]; y1 = box[3]; }
        // Emniyet: ölçümler (kol, C ucu, dudak kıvrımı) yanlış yere düştüyse çerçeve dişleri neredeyse tam sarar. Diş sınırı geçerliyse
        // çerçeve diş boyunun/enininin en az roomH/roomW katı olmalı: önce modelin kutusu denenir, o da dar ise diş kutusu merkez alınarak
        // genişletilir (görüntü sınırında kaydırılır).
        if (!sideways) {
            const ttop = num(item.teeth_top), tbot = num(item.teeth_bottom), tlef = num(item.teeth_left), trig = num(item.teeth_right);
            if (tbot > ttop && trig > tlef) {
                const minH = (tbot - ttop) * SETTINGS.roomH, minW = /^labial_/.test(item.slot || '') ? (trig - tlef) * SETTINGS.roomW : 0;
                if (y1 - y0 < minH || x1 - x0 < minW) {
                    const big = box[3] - box[1] >= minH && box[2] - box[0] >= minW;
                    if (big) {
                        x0 = Math.min(box[0], tlef - 0.01); y0 = Math.min(box[1], ttop - 0.015);
                        x1 = Math.max(box[2], trig + 0.01); y1 = Math.max(box[3], tbot + 0.015);
                        used.room = 'model kutusu';
                    } else {
                        const cx = (tlef + trig) / 2, cy = (ttop + tbot) / 2;
                        const hw = Math.max(minW, (trig - tlef) + 0.02) / 2, hh = Math.max(minH, (tbot - ttop) + 0.03) / 2;
                        x0 = cx - hw; x1 = cx + hw; y0 = cy - hh; y1 = cy + hh;
                        if (x0 < 0) { x1 -= x0; x0 = 0; }
                        if (x1 > 1) { x0 -= x1 - 1; x1 = 1; }
                        if (y0 < 0) { y1 -= y0; y0 = 0; }
                        if (y1 > 1) { y0 -= y1 - 1; y1 = 1; }
                        used.room = 'diş kutusu genişletildi';
                    }
                    x0 = Math.max(0, x0); y0 = Math.max(0, y0); x1 = Math.min(1, x1); y1 = Math.min(1, y1);
                }
            }
        }
        return {
            box: [x0, y0, x1, y1], tilt: tilt, angle: angle, pivot: pivot,
            plane: hasPlane ? [p0[0], p0[1], p1[0], p1[1]] : null, teeth: teeth, lips: lips, sides: sides, arms: arms, used: used,
            upper: arms.filter(function (a) { return a.upper; }).length,
            lower: arms.filter(function (a) { return !a.upper; }).length
        };
    }

    // Oklüzal: modelin kutusu gevşek kalıyordu (yüz, çene, ekartör kadrajda); çerçeve ölçülen diş sınırından kurulur.
    // Ölçüm yoksa ya da anlamsızsa null (modelin kutusu kullanılır).
    function occlusalBox(item) {
        const l = num(item.teeth_left), r = num(item.teeth_right), t = num(item.teeth_top), b = num(item.teeth_bottom);
        if (!(r - l > 0.1 && b - t > 0.1) || l < 0 || t < 0 || r > 1 || b > 1) return null;
        return [l, t, r, b];
    }

    // Yan duran (dik tutulmuş) kare: model ölçümleri ve kutuyu düzlemi yatay yapan döndürülmüş karede verir (view_rotation 90/270);
    // çerçeve orada hesaplanır, sonuç ham kareye geri çevrilir. Çıkan kutu ham kare eksenlerindedir; eğim (tilt) aynı yönde ve
    // pivot ham karede olduğundan cropOne değişmez. Ham kareye ait olmayan ayrıntılar (düzlem, kollar vb.) boşaltılır.
    function intraoralFrameAny(item, w, h) {
        const rot = Number(item.view_rotation) || 0;
        if (rot !== 90 && rot !== 270) return intraoralFrame(item, w, h);
        const f = intraoralFrame(item, h, w);
        const back = function (x, y) { return rot === 90 ? [y, 1 - x] : [1 - y, x]; };
        const a = back(f.box[0], f.box[1]);
        const b = back(f.box[2], f.box[3]);
        f.box = [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1])];
        f.pivot = back(f.pivot[0], f.pivot[1]);
        f.plane = null; f.teeth = null; f.lips = null; f.sides = null; f.arms = [];
        f.rotated = rot;
        return f;
    }

    function toBlob(canvas) {
        return new Promise(function (resolve) { canvas.toBlob(resolve, 'image/jpeg', SETTINGS.quality); });
    }

    // 16×16 gri imza: IDS yuvasındaki önizlemenin hangi kırpılmış dosya olduğunu bulmak için.
    const SIG = 16;
    function signatureOf(source, w, h) {
        const canvas = document.createElement('canvas');
        canvas.width = SIG;
        canvas.height = SIG;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(source, 0, 0, w, h, 0, 0, SIG, SIG);
        const px = ctx.getImageData(0, 0, SIG, SIG).data;
        const out = new Array(SIG * SIG);
        for (let i = 0; i < out.length; i++) out[i] = px[i * 4] * 0.299 + px[i * 4 + 1] * 0.587 + px[i * 4 + 2] * 0.114;
        return out;
    }

    function distance(a, b) {
        let sum = 0;
        for (let i = 0; i < a.length; i++) sum += Math.abs(a[i] - b[i]);
        return sum / a.length;
    }

    // İmzanın saat yönünde 90° döndürülmüş hali (16×16 ızgara döndürülür; görüntüyü döndürüp imza almakla aynı sonuç).
    function rotateSig(sig) {
        const out = new Array(SIG * SIG);
        for (let y = 0; y < SIG; y++) for (let x = 0; x < SIG; x++) out[x * SIG + (SIG - 1 - y)] = sig[y * SIG + x];
        return out;
    }

    // İmzanın dört yönü (IDS önizlemesi EXIF'i uygulamış ya da uygulamamış, ya da kare bizce döndürülmüş olabilir).
    function sigVariants(sig) {
        const list = [sig];
        for (let i = 0; i < 3; i++) list.push(rotateSig(list[i]));
        return list;
    }

    function bestDistance(sig, itemSig) {
        let best = Infinity;
        sigVariants(itemSig).forEach(function (v) { const d = distance(sig, v); if (d < best) best = d; });
        return best;
    }

    // Önizleme (IDS'in küçülttüğü yüklenmiş kare) hangi dosyaya ait? En iyi eşleşmeye yakın (+8) olanların hepsi döner: benzer çekimler
    // (ikizler) imzayla ayırt edilemez; hangisi olduğu önemsizdir, en netleri seçilir. Hiçbiri yeterince yakın değilse boş dizi.
    async function matchGroup(blob, items) {
        if (!items || !items.length) return [];
        const bitmap = await createImageBitmap(blob);
        try {
            const sig = signatureOf(bitmap, bitmap.width, bitmap.height);
            const ranked = items.filter(function (it) { return it.sig; })
                .map(function (it) { return { item: it, d: bestDistance(sig, it.sig) }; })
                .sort(function (a, b) { return a.d - b.d; });
            if (!ranked.length || ranked[0].d > 20) return [];
            return ranked.filter(function (r) { return r.d < ranked[0].d + 8; }).map(function (r) { return r.item; });
        } finally {
            bitmap.close();
        }
    }

    // Belirsizse (benzer çekimler) null.
    async function matchOriginal(blob, items) {
        const group = await matchGroup(blob, items);
        return group.length === 1 ? group[0] : null;
    }

    // Ham karede üst çenenin ve ön dişlerin yönünden ağız içi yan karenin yanı: üst çene yukarı gelecek şekilde
    // döndürülünce ön dişler sağdaysa sağ bukkal, soldaysa sol bukkal (kliniğin kuralı; fotoğraflar aynasız çekilir).
    // Belirsizse null.
    const SIDE_DEG = { top: 0, right: 90, bottom: 180, left: 270 };
    function buccalSide(upper, incisors) {
        const u = SIDE_DEG[upper];
        const n = SIDE_DEG[incisors];
        if (u === undefined || n === undefined) return null;
        const after = (((n - u) % 360) + 360) % 360;
        return after === 90 ? 'buccal_right' : after === 270 ? 'buccal_left' : null;
    }

    // box: kesirler (eğim varsa döndürülmüş karede); tilt: oklüzal düzlemin eğimi (derece, sağa doğru aşağı = pozitif); pivot: döndürme
    // merkezi (kesir). Görüntü pivot etrafında -tilt döndürülüp kutu o karede kesilir (oklüzal düzlem yere paralel olur). orient:
    // {rotate, mirror}: kesilen kare önce saat yönünde rotate kadar döndürülür, sonra mirror ise sağ-sol aynalanır (IDS menüsündeki sıra).
    async function cropOne(file, box, tilt, pivot, orient) {
        const bitmap = await bitmapOf(file);
        try {
            const sx = Math.round(box[0] * bitmap.width), sy = Math.round(box[1] * bitmap.height);
            const sw = Math.max(1, Math.round((box[2] - box[0]) * bitmap.width));
            const sh = Math.max(1, Math.round((box[3] - box[1]) * bitmap.height));
            const canvas = document.createElement('canvas');
            canvas.width = sw;
            canvas.height = sh;
            const ctx = canvas.getContext('2d');
            if (tilt) {
                const px = (pivot ? pivot[0] : (box[0] + box[2]) / 2) * bitmap.width;
                const py = (pivot ? pivot[1] : (box[1] + box[3]) / 2) * bitmap.height;
                ctx.fillStyle = '#000';
                ctx.fillRect(0, 0, sw, sh);
                ctx.translate(px - sx, py - sy);
                ctx.rotate(-tilt * Math.PI / 180);
                ctx.translate(-px, -py);
                ctx.drawImage(bitmap, 0, 0);
                ctx.setTransform(1, 0, 0, 1, 0, 0);
            } else {
                ctx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, sw, sh);
            }
            // Yön: önce saat yönünde orient.rotate kadar döndürülür, sonra orient.mirror ise sağ-sol aynalanır (IDS menüsündeki sıra).
            let fin = canvas;
            if (orient && (orient.rotate || orient.mirror)) {
                const rot = orient.rotate || 0;
                fin = document.createElement('canvas');
                fin.width = rot % 180 ? sh : sw;
                fin.height = rot % 180 ? sw : sh;
                const g = fin.getContext('2d');
                g.translate(fin.width / 2, fin.height / 2);
                if (orient.mirror) g.scale(-1, 1);
                g.rotate(rot * Math.PI / 180);
                g.drawImage(canvas, -sw / 2, -sh / 2);
            }
            const sig = signatureOf(fin, fin.width, fin.height);
            const blob = await toBlob(fin);
            if (!blob) throw new Error('kırpılmış görüntü üretilemedi');
            const name = file.name.replace(/\.[^.]+$/, '') + '.jpg';
            return { file: new File([blob], name, { type: 'image/jpeg', lastModified: file.lastModified }), width: fin.width, height: fin.height, sig: sig };
        } finally {
            bitmap.close();
        }
    }

    // Yuvası bilinen karelerin kırpma kutusu ve ölçümleri: entries = [{ item, slot }]. Tek çağrı (6'lık gruplar aynı anda); oklüzal
    // kareler için diş sırası kutusu ayrıca odaklı okumayla (ids-arch) alınır ve geçerliyse ölçümlerin yerine konur.
    // Dönüş: { byName: { ad: modelÇıktısı }, notes: [] }.
    async function readBoxes(entries, progress) {
        const say = progress || function () {};
        const byName = {};
        const notes = [];
        const groups = [];
        for (let i = 0; i < entries.length; i += SETTINGS.groupSize) groups.push(entries.slice(i, i + SETTINGS.groupSize));
        let answered = 0;
        const cropWork = groups.map(async function (group) {
            try {
                const reply = await sendHedged({
                    type: 'ids-crop', effort: SETTINGS.cropEffort, known: true,
                    images: group.map(function (e, k) { return { index: k + 1, slot: e.slot, data: e.item.thumb }; })
                });
                (reply.items || []).forEach(function (r) {
                    const e = group[Number(r.index) - 1];
                    if (!e) return;
                    r.slot = e.slot;
                    byName[e.item.name] = r;
                });
            } catch (error) {
                group.forEach(function (e) { notes.push(e.item.name + ': kırpma kutusu alınamadı (' + error.message + ')'); });
            }
            answered++;
            say('Kırpma kutuları okunuyor… (' + answered + '/' + groups.length + ')');
        });
        const occl = entries.filter(function (e) { return OCCLUSAL.test(e.slot); });
        const archWork = (async function () {
            if (!occl.length) return;
            try {
                const reply = await sendHedged({
                    type: 'ids-arch', effort: SETTINGS.archEffort, model: SETTINGS.archModel,
                    images: occl.map(function (e, k) { return { index: k + 1, data: e.item.thumb }; })
                });
                await Promise.all(cropWork);
                (reply.items || []).forEach(function (r) {
                    const e = occl[Number(r.index) - 1];
                    if (!e) return;
                    const l = num(r.teeth_left), rt = num(r.teeth_right), t = num(r.teeth_top), b = num(r.teeth_bottom);
                    const sane = rt - l > 0.1 && b - t > 0.1 && l >= 0 && t >= 0 && rt <= 1 && b <= 1 && (rt - l) * (b - t) < 0.92;
                    const m = byName[e.item.name] || (byName[e.item.name] = { slot: e.slot, x0: 0, y0: 0, x1: 1, y1: 1, note: '' });
                    if (sane) { m.teeth_left = l; m.teeth_right = rt; m.teeth_top = t; m.teeth_bottom = b; m.arch_checked = true; }
                    else notes.push(e.item.name + ': oklüzal diş sırası kutusu güvenilir ölçülemedi, ilk ölçüm kullanıldı');
                });
            } catch (error) {
                occl.forEach(function (e) { notes.push(e.item.name + ': oklüzal diş sırası okuması alınamadı (' + error.message + ')'); });
            }
        })();
        await Promise.all(cropWork.concat([archWork]));
        return { byName: byName, notes: notes };
    }

    // Yuvası bilinmeyen kareleri etiketler (IDS'in boş bıraktığı yuvaları doldurmak için): { ad: yuva } (düşük güven → 'other').
    async function classify(items, progress) {
        const say = progress || function () {};
        const labels = {};
        const groups = [];
        for (let i = 0; i < items.length; i += SETTINGS.groupSize) groups.push(items.slice(i, i + SETTINGS.groupSize));
        let answered = 0;
        await Promise.all(groups.map(async function (group) {
            try {
                const reply = await sendHedged({
                    type: 'ids-crop', effort: SETTINGS.cropEffort,
                    images: group.map(function (it, k) { return { index: k + 1, data: it.thumb }; })
                });
                (reply.items || []).forEach(function (r) {
                    const it = group[Number(r.index) - 1];
                    if (!it) return;
                    labels[it.name] = Number(r.confidence) >= SETTINGS.minConfidence ? r.slot : 'other';
                });
            } catch (error) {
                group.forEach(function (it) { labels[it.name] = 'other'; });
            }
            answered++;
            say('Yerleşmeyen fotoğraflar sınıflandırılıyor… (' + answered + '/' + groups.length + ')');
        }));
        return labels;
    }

    // Yuvası bilinen kare için son çerçeve: { box, tilt, pivot, notes } ya da null (kutu geçersiz).
    function frameFor(model, slot, w, h) {
        const notes = [];
        const item = Object.assign({}, model, { slot: slot });
        const face = FACE.test(slot);
        const frame = INTRAORAL.test(slot) ? intraoralFrameAny(item, w, h) : null;
        const occ = OCCLUSAL.test(slot) ? occlusalBox(item) : null;
        let box = finalBox(frame ? frame.box : (occ || [item.x0, item.y0, item.x1, item.y1]),
            face ? SETTINGS.faceMargin : (occ ? SETTINGS.occlusalMargin : SETTINGS.margin), face ? SETTINGS.faceRatio : 0, w, h);
        if (!box) return null;
        if (!face) box = relaxBox(box, w, h, frame ? SETTINGS.maxAspect : 0, SETTINGS.minOutW, SETTINGS.minOutH);
        if (OCCLUSAL.test(slot)) {
            if (!occ) notes.push('oklüzal diş sınırı ölçülemedi, modelin kutusu kullanıldı');
            else if ((box[2] - box[0]) * (box[3] - box[1]) > 0.9) notes.push('oklüzal kutu neredeyse tüm kareyi kaplıyor, kırpma etkisiz');
        }
        const tilt = frame ? frame.tilt : 0;
        if (tilt) notes.push('oklüzal düzlem ' + Math.abs(tilt).toFixed(1) + '° düzeltildi');
        if (frame && !frame.rotated && !frame.upper && !frame.lower) notes.push('ekartör kolu ölçülemedi, modelin kutusu kullanıldı');
        if (frame && frame.used && frame.used.room) notes.push('çerçeve dişleri sarıyordu, genişletildi (' + frame.used.room + ')');
        return { box: box, tilt: tilt, pivot: frame ? frame.pivot : null, notes: notes };
    }

    // Yuvası ve yönü bilinen kareyi kırpar ve döndürür: { file, width, height, notes }. model yoksa (kutu alınamadı) yalnız döndürülür.
    async function cropFor(item, slot, model, orient) {
        const frame = model ? frameFor(model, slot, item.w, item.h) : null;
        const box = frame ? frame.box : [0, 0, 1, 1];
        const result = await cropOne(item.file, box, frame ? frame.tilt : 0, frame ? frame.pivot : null, orient);
        result.notes = (frame ? frame.notes : ['kırpma kutusu yok, yalnız yön düzeltildi']).map(function (n) { return item.name + ': ' + n; });
        result.cropped = !!frame;
        return result;
    }

    // Kırpılmamış hali, yönü düzeltilmiş olarak ("Kırpılmamış hallerine dön").
    function fullFor(item, orient) {
        return cropOne(item.file, [0, 0, 1, 1], 0, null, orient);
    }

    window.idsfyCrop = { prepare: prepare, classify: classify, readBoxes: readBoxes, frameFor: frameFor, cropFor: cropFor, fullFor: fullFor,
        cropOne: cropOne, matchGroup: matchGroup, matchOriginal: matchOriginal, buccalSide: buccalSide, qualityScore: qualityScore,
        relaxBox: relaxBox, finalBox: finalBox, intraoralFrame: intraoralFrame, intraoralFrameAny: intraoralFrameAny, occlusalBox: occlusalBox,
        SETTINGS: SETTINGS };
})();
